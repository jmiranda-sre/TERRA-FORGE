/*
 * ============================================================================
 *  AURIS SHADER — lib/settings.glsl
 * ============================================================================
 *  Fonte única de verdade para todas as opções expostas na GUI de shaders
 *  do Iris. Cada linha "#define NOME valor // [lista de valores]" abaixo é
 *  reconhecida pelo parser do Iris/OptiFine e vira um controle na tela de
 *  opções (organizados via `screen.*` no shaders.properties).
 *
 *  Os `profile.Low/Medium/High/Ultra` do shaders.properties funcionam como
 *  ATALHOS: eles sobrescrevem em lote os valores destas macros quando o
 *  jogador troca de perfil na GUI. Quem efetivamente muda o custo de
 *  performance são os `#if` / `#ifdef` espalhados pelos arquivos .fsh/.vsh
 *  que testam essas macros — quando uma feature está desligada, o branch
 *  inteiro é eliminado do shader compilado (dead code elimination real),
 *  não apenas "value = 0" mantendo o cálculo vivo.
 *
 *  Este arquivo é incluído via `#include "/lib/settings.glsl"` como a
 *  PRIMEIRA linha de include em todo .fsh/.vsh do pack.
 * ============================================================================
 */

#ifndef AURIS_SETTINGS_INCLUDED
#define AURIS_SETTINGS_INCLUDED

// ---------------------------------------------------------------------------
// Perfil ativo — apenas para exibição/diagnóstico (ex: debug overlay).
// A lógica real de corte de custo NUNCA testa esta macro diretamente;
// ela testa as macros individuais abaixo, que o profile.* sobrescreve.
// ---------------------------------------------------------------------------
#define PROFILE 1 // [0 1 2 3] 0=Low 1=Medium 2=High 3=Ultra

// ---------------------------------------------------------------------------
// SOMBRAS
// ---------------------------------------------------------------------------
#define SHADOW_RES 2048         // [1024 1536 2048 3072 4096]
#define SOFT_SHADOWS 1          // [0 1 2] 0=hard (1 sample) 1=PCF leve (4 samples) 2=PCSS (penumbra variável)
#define SHADOW_DISTORT 1        // [0 1] Warp de projeção (pseudo-cascata: mais texel perto do player)
#define COLORED_SHADOWS 0       // [0 1] Transmitância de cor via shadowcolor0 (vidro/folha tingindo a sombra)
#define SHADOW_DISTANCE 128.0   // [64.0 96.0 128.0 160.0 200.0]
#define SHADOW_ENTITIES 1       // [0 1] Entidades projetam sombra (custa 1 draw call a mais no shadow pass)

// ---------------------------------------------------------------------------
// ILUMINAÇÃO / AO / GI
// ---------------------------------------------------------------------------
#define SSAO_SAMPLES 4          // [0 4 8 16] 0 desliga SSAO por completo (sem loop, sem sample)
#define GI_APPROX 0             // [0 1] Bounce-light aproximado (blur do buffer iluminado, High/Ultra)

// ---------------------------------------------------------------------------
// ÁGUA
// ---------------------------------------------------------------------------
#define WATER_REFLECTION 1      // [0 1 2 3] 0=nenhum 1=especular 2=céu 3=SSR
#define SSR_STEPS 0             // [0 16 32 64] 0 = SSR desligado (usa WATER_REFLECTION como fallback)
#define WATER_REFRACTION 1      // [0 1 2] 0=off 1=leve (offset simples) 2=detalhada (Snell aproximado)
#define WATER_PARALLAX 0        // [0 1] Parallax simples na superfície da água (Ultra)
#define CAUSTICS 0              // [0 1] Caustics projetadas no fundo (Ultra)

// ---------------------------------------------------------------------------
// ATMOSFERA / VOLUMÉTRICOS
// ---------------------------------------------------------------------------
#define VL_STEPS 8              // [0 8 12 16 24 32] 0 desliga volumetric light (god rays)
#define CLOUDS_MODE 1           // [0 1 2] 0=off 1=camada 2D barata 2=raymarch 3D

// ---------------------------------------------------------------------------
// PÓS-PROCESSAMENTO
// ---------------------------------------------------------------------------
#define BLOOM_QUALITY 1         // [0 1 2] 0=off 1=barato (1 downsample) 2=completo (mip chain)
#define DOF_ENABLED 0           // [0 1]
#define MOTION_BLUR_ENABLED 0   // [0 1]
#define POM_ENABLED 0           // [0 1] Parallax occlusion mapping em texturas com heightmap
#define EYE_ADAPTATION 0        // [0 1] Auto-exposure
#define COLOR_GRADE_STRENGTH 1  // [0 1 2] 0=neutro 1=sutil 2=estilizado

// ---------------------------------------------------------------------------
// TEMPORAL
// ---------------------------------------------------------------------------
// Toda técnica de ruído (SSAO, VL, SSR, clouds raymarch) usa reprojeção
// temporal em vez de multi-sampling por frame: acumula 1 sample novo por
// frame em colortexN e reprojeta o histórico usando o depth + previous
// matrices. Isso reduz ruído sem multiplicar o custo por sample.
#define TAA_BLEND_WEIGHT 0.92   // Peso do histórico na reprojeção (quanto maior, mais suave e mais "ghosting" em movimento)

// ---------------------------------------------------------------------------
// Constantes internas (não expostas na GUI)
// ---------------------------------------------------------------------------
#define AURIS_PI 3.14159265359
#define AURIS_TAU 6.28318530718
#define AURIS_HALF_PI 1.5707963268

#endif // AURIS_SETTINGS_INCLUDED
