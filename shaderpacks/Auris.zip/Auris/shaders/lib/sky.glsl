/*
 * ============================================================================
 *  AURIS SHADER — lib/sky.glsl  (variante OVERWORLD — arquivo base)
 * ============================================================================
 *  Assim como lib/fog.glsl, este arquivo tem cópias próprias em
 *  world-1/lib/sky.glsl (Nether) e world1/lib/sky.glsl (End) — ver nota
 *  detalhada em lib/fog.glsl sobre o mecanismo de override por pasta.
 *
 *  Fornece: gradiente de céu procedural, posição/cor de sol e lua, e o
 *  "timeOfDayFactor" usado por lib/fog.glsl e composite1.fsh (intensidade
 *  do volumetric light).
 *
 *  Ativo em: todos os profiles (o gradiente de céu em si é O(1); estrelas
 *  usam a mesma textura vanilla, sem raymarch).
 * ============================================================================
 */

#ifndef AURIS_SKY_INCLUDED
#define AURIS_SKY_INCLUDED

#include "/lib/settings.glsl"

// Gradiente procedural de céu do Overworld: horizonte mais claro/quente,
// zênite mais escuro/azul, interpolado por altura do vetor de view.
vec3 auris_skyGradient(vec3 viewDir, vec3 sunDir, float timeOfDayFactor, float rainStrength) {
    float horizonBlend = pow(1.0 - clamp(abs(viewDir.y), 0.0, 1.0), 2.2);

    vec3 zenithDay   = vec3(0.29, 0.49, 0.82);
    vec3 horizonDay  = vec3(0.62, 0.74, 0.88);
    vec3 zenithNight = vec3(0.015, 0.02, 0.045);
    vec3 horizonNight= vec3(0.03, 0.035, 0.06);

    vec3 zenith  = mix(zenithNight, zenithDay, timeOfDayFactor);
    vec3 horizon = mix(horizonNight, horizonDay, timeOfDayFactor);

    vec3 sky = mix(zenith, horizon, horizonBlend);

    // Glow ao redor do sol/lua (barato: dot product, sem textura extra)
    float sunDot = clamp(dot(viewDir, sunDir), 0.0, 1.0);
    vec3 sunGlow = vec3(1.0, 0.78, 0.5) * pow(sunDot, 64.0) * timeOfDayFactor * 0.6;

    sky += sunGlow;
    sky = mix(sky, sky * 0.6 + vec3(0.5, 0.52, 0.55) * 0.4, rainStrength); // céu nublado dessatura

    return sky;
}

// Fator dia/noite suave (0 = meia-noite, 1 = meio-dia), derivado do
// worldTime vanilla (0-24000) — evita depender de shadowLightPosition
// pra não quebrar em ângulos raros durante transição.
float auris_timeOfDayFactor(float worldTimeNorm) {
    // worldTimeNorm esperado em [0,1), onde 0 = amanhecer.
    float angle = worldTimeNorm * AURIS_TAU;
    return clamp(sin(angle) * 1.15 + 0.15, 0.0, 1.0);
}

#endif // AURIS_SKY_INCLUDED
