/*
 * ============================================================================
 *  AURIS SHADER — lib/fog.glsl  (variante OVERWORLD — arquivo base)
 * ============================================================================
 *  Esta é a versão de `lib/fog.glsl` usada quando o Iris carrega os
 *  shaders da pasta raiz, ou seja: Overworld.
 *
 *  IMPORTANTE sobre a estratégia multi-dimensão do Auris:
 *  Nether e End têm cada um sua PRÓPRIA cópia deste arquivo dentro de
 *  `world-1/lib/fog.glsl` (Nether) e `world1/lib/fog.glsl` (End) — o Iris,
 *  como o OptiFine, resolve automaticamente `#include "/lib/fog.glsl"`
 *  para o arquivo da pasta da dimensão atual quando ela existe, caindo de
 *  volta pra pasta raiz quando não existe. Isso evita `#ifdef NETHER` /
 *  `#ifdef END` (que não existem como macro padrão) e evita qualquer
 *  branch em runtime: cada dimensão literalmente compila um shader
 *  diferente, sem custo de comparação nem código morto a eliminar.
 *
 *  Ativo em: todos os profiles. O CUSTO de fog é O(1) sempre — a única
 *  coisa que varia por profile é se a névoa volumétrica de sol (god rays)
 *  roda por cima dela (ver VL_STEPS em composite1.fsh).
 * ============================================================================
 */

#ifndef AURIS_FOG_INCLUDED
#define AURIS_FOG_INCLUDED

// Névoa exponencial padrão do Overworld — densidade cresce com a distância
// e é modulada pela altura (névoa mais densa perto do chão, rarefeita alto
// no céu) pra dar leitura de escala sem custar mais que um exp().
vec3 auris_applyOverworldFog(vec3 color, vec3 skyFogColor, float viewDistance,
                              float fragWorldHeight, float rainStrength,
                              float timeOfDayFactor) {
    // Densidade base: sobe na chuva (fog de chuva mais denso e mais cinza).
    float density = mix(0.0035, 0.011, rainStrength);

    // Atenua a névoa em Y alto (topo do mundo) pra não "engolir" nuvens/céu
    // com névoa de chão à toa.
    float heightFalloff = clamp(1.0 - (fragWorldHeight - 62.0) / 190.0, 0.35, 1.0);

    float fogFactor = 1.0 - exp(-density * heightFalloff * viewDistance);
    fogFactor = clamp(fogFactor, 0.0, 1.0);

    // Escurece levemente a cor da névoa ao entardecer/amanhecer/noite —
    // timeOfDayFactor vem de lib/sky.glsl (1.0 = meio-dia, 0.0 = meia-noite).
    vec3 tintedFog = skyFogColor * mix(0.55, 1.0, timeOfDayFactor);

    return mix(color, tintedFog, fogFactor);
}

// Névoa de água/submerso — usada em gbuffers_water.fsh e em qualquer
// gbuffer quando `isEyeInWater == 1`. Beer-Lambert simplificado.
vec3 auris_applyWaterFog(vec3 color, vec3 waterAbsorb, float travelDistance) {
    vec3 transmittance = exp(-waterAbsorb * travelDistance);
    vec3 waterTint = vec3(0.02, 0.09, 0.11);
    return mix(waterTint, color, transmittance);
}

#endif // AURIS_FOG_INCLUDED
