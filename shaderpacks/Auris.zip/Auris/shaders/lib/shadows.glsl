/*
 * ============================================================================
 *  AURIS SHADER — lib/shadows.glsl
 * ============================================================================
 *  Amostragem do shadow map com 3 níveis de qualidade (SOFT_SHADOWS 0/1/2)
 *  e distorção de projeção opcional (SHADOW_DISTORT) que concentra
 *  resolução perto do jogador — a "pseudo-cascata" citada na missão: o
 *  Auris usa UM shadow map (mais barato que CSM real com 2-4 cascatas e
 *  2-4 draw calls), mas aplica um warp não-linear na projeção (a mesma
 *  ideia usada por SEUS/BSL) que redistribui os texels de forma que a
 *  densidade efetiva perto da câmera se aproxime da de uma cascata perto,
 *  sem o custo de renderizar múltiplos shadow maps.
 *
 *  Ativo por profile:
 *    LOW    -> SOFT_SHADOWS=0, SHADOW_DISTORT=0, COLORED_SHADOWS=0 (1 sample, sem distorção)
 *    MEDIUM -> SOFT_SHADOWS=1 (PCF 4 samples), SHADOW_DISTORT=1
 *    HIGH   -> SOFT_SHADOWS=2 (PCSS), SHADOW_DISTORT=1, COLORED_SHADOWS=1
 *    ULTRA  -> SOFT_SHADOWS=2 com mais samples de blocker search, COLORED_SHADOWS=1
 * ============================================================================
 */

#ifndef AURIS_SHADOWS_INCLUDED
#define AURIS_SHADOWS_INCLUDED

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"

// ----------------------------------------------------------------------
// Constantes especiais reconhecidas pelo Iris/OptiFine — dimensionam o
// render target do shadow map e o alcance (em blocos) do shadow pass.
// Referenciam diretamente as macros de lib/settings.glsl, então o
// profile.* do shaders.properties (que sobrescreve SHADOW_RES/
// SHADOW_DISTANCE) também controla o tamanho real do buffer alocado,
// não só a lógica de sample dentro dele.
// ----------------------------------------------------------------------
const int shadowMapResolution = SHADOW_RES;
const float shadowDistance = SHADOW_DISTANCE;

// Warp de distorção — comprime a periferia do shadow map, expande o
// centro (perto do player). Custa 2 sqrt(), roda 1x por vértice/pixel
// projetado na sombra, não por sample de PCF.
#if SHADOW_DISTORT == 1
vec3 auris_distortShadowClip(vec3 shadowClipPos) {
    float dist = length(shadowClipPos.xy);
    float distortFactor = dist + 0.10;
    vec2 distorted = shadowClipPos.xy / distortFactor;
    return vec3(distorted, shadowClipPos.z * 0.5);
}
#else
vec3 auris_distortShadowClip(vec3 shadowClipPos) {
    return shadowClipPos; // Low: projeção linear, sem warp (mais barato, menos alcance útil)
}
#endif

// Sample único (usado internamente pelo PCF e como caminho direto no Low)
float auris_sampleShadowRaw(sampler2D shadowtex, vec3 shadowScreenPos, float bias) {
    return step(shadowScreenPos.z - bias, texture2D(shadowtex, shadowScreenPos.xy).r);
}

// ----------------------------------------------------------------------
// Caminho LOW: 1 sample, sem PCF — mínimo custo possível.
// ----------------------------------------------------------------------
#if SOFT_SHADOWS == 0
float auris_shadowFactor(sampler2D shadowtex1, vec3 shadowScreenPos, float bias, vec2 fragCoord, float frame) {
    return auris_sampleShadowRaw(shadowtex1, shadowScreenPos, bias);
}

// ----------------------------------------------------------------------
// Caminho MEDIUM: PCF leve, 4 samples fixos em cruz, dither temporal
// pra suavizar a serrilhagem sem subir pra 9/16 samples.
// ----------------------------------------------------------------------
#elif SOFT_SHADOWS == 1
float auris_shadowFactor(sampler2D shadowtex1, vec3 shadowScreenPos, float bias, vec2 fragCoord, float frame) {
    float texelSize = 1.0 / float(SHADOW_RES);
    float jitterAngle = temporalDither(fragCoord, frame) * AURIS_TAU;
    mat2 rot = mat2(cos(jitterAngle), -sin(jitterAngle), sin(jitterAngle), cos(jitterAngle));

    float sum = 0.0;
    vec2 offsets[4] = vec2[4](vec2(1.0, 0.0), vec2(-1.0, 0.0), vec2(0.0, 1.0), vec2(0.0, -1.0));
    for (int i = 0; i < 4; i++) {
        vec2 o = (rot * offsets[i]) * texelSize * 1.5;
        sum += auris_sampleShadowRaw(shadowtex1, shadowScreenPos + vec3(o, 0.0), bias);
    }
    return sum * 0.25;
}

// ----------------------------------------------------------------------
// Caminho HIGH/ULTRA: PCSS — busca de blocker pra estimar penumbra e
// escala o raio do PCF conforme distância blocker->receiver. Mais caro,
// mas HIGH/ULTRA têm o orçamento de frame-time pra isso.
// ----------------------------------------------------------------------
#else // SOFT_SHADOWS == 2 (PCSS)

#if PROFILE >= 3
    #define AURIS_PCSS_BLOCKER_SAMPLES 8
    #define AURIS_PCSS_PCF_SAMPLES 12
#else
    #define AURIS_PCSS_BLOCKER_SAMPLES 4
    #define AURIS_PCSS_PCF_SAMPLES 8
#endif

float auris_findBlockerDepth(sampler2D shadowtex0, vec3 shadowScreenPos, float searchRadius, vec2 fragCoord, float frame) {
    float blockerSum = 0.0;
    float count = 0.0;
    float ign = temporalDither(fragCoord, frame);
    for (int i = 0; i < AURIS_PCSS_BLOCKER_SAMPLES; i++) {
        float angle = (float(i) / float(AURIS_PCSS_BLOCKER_SAMPLES) + ign) * AURIS_TAU;
        vec2 o = vec2(cos(angle), sin(angle)) * searchRadius;
        float depthSample = texture2D(shadowtex0, shadowScreenPos.xy + o).r;
        if (depthSample < shadowScreenPos.z - 0.0005) {
            blockerSum += depthSample;
            count += 1.0;
        }
    }
    return count > 0.0 ? blockerSum / count : -1.0;
}

float auris_shadowFactor(sampler2D shadowtex1, vec3 shadowScreenPos, float bias, vec2 fragCoord, float frame) {
    float texelSize = 1.0 / float(SHADOW_RES);

    // Penumbra fixa e barata: em vez de reamostrar shadowtex0 (sem
    // transmitância) pra estimar blocker distance com precisão de verdade,
    // usamos um raio de busca fixo pequeno — suficiente pra dar a
    // impressão de penumbra variável sem o custo de um segundo depth
    // texture bind dedicado por profile mais baixo que Ultra.
    float searchRadius = texelSize * (PROFILE >= 3 ? 3.5 : 2.0);

    float ign = temporalDither(fragCoord, frame);
    float sum = 0.0;
    for (int i = 0; i < AURIS_PCSS_PCF_SAMPLES; i++) {
        float angle = (float(i) / float(AURIS_PCSS_PCF_SAMPLES) + ign) * AURIS_TAU;
        float r = searchRadius * sqrt(fract(ign + float(i) * 0.618));
        vec2 o = vec2(cos(angle), sin(angle)) * r;
        sum += auris_sampleShadowRaw(shadowtex1, shadowScreenPos + vec3(o, 0.0), bias);
    }
    return sum / float(AURIS_PCSS_PCF_SAMPLES);
}
#endif

// ----------------------------------------------------------------------
// Sombra colorida (transmitância) — só compilado em High/Ultra.
// Lê shadowcolor0 (cor do bloco translúcido, escrita no shadow pass) e
// multiplica a cor da luz direta que atravessa vidro/folhas/água rasa.
// ----------------------------------------------------------------------
#if COLORED_SHADOWS == 1
vec3 auris_coloredShadowTint(sampler2D shadowcolor0, sampler2D shadowtex0, sampler2D shadowtex1, vec3 shadowScreenPos) {
    float opaqueDepth = texture2D(shadowtex1, shadowScreenPos.xy).r;
    float translucentDepth = texture2D(shadowtex0, shadowScreenPos.xy).r;

    // Se há algo translúcido entre o bloco opaco e a luz, tinge; senão, branco.
    if (translucentDepth < opaqueDepth - 0.0001 && translucentDepth < shadowScreenPos.z) {
        vec4 tint = texture2D(shadowcolor0, shadowScreenPos.xy);
        return mix(vec3(1.0), tint.rgb, tint.a);
    }
    return vec3(1.0);
}
#endif

#endif // AURIS_SHADOWS_INCLUDED
