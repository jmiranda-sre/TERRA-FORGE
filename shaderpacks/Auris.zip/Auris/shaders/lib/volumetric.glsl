/*
 * ============================================================================
 *  AURIS SHADER — lib/volumetric.glsl
 * ============================================================================
 *  Volumetric light (god rays) em screen-space: marcha do fragmento até a
 *  câmera, testando visibilidade no shadow map a cada passo. VL_STEPS=0
 *  remove a função inteira do shader compilado (chamada é guardada por
 *  `#if VL_STEPS > 0` no composite1.fsh).
 *
 *  O resultado é acumulado por 1 sample/frame e reprojetado no histórico
 *  em composite2.fsh (denoising temporal), então mesmo 8 steps (Medium)
 *  fica visualmente estável — a alternativa de "força bruta" seria 32+
 *  steps por frame sem reprojeção, que o Auris explicitamente evita.
 *
 *  Ativo por profile:
 *    LOW    -> VL_STEPS=0 (desligado)
 *    MEDIUM -> VL_STEPS=8-12
 *    HIGH   -> VL_STEPS=16-24
 *    ULTRA  -> VL_STEPS=32
 * ============================================================================
 */

#ifndef AURIS_VOLUMETRIC_INCLUDED
#define AURIS_VOLUMETRIC_INCLUDED

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"

#if VL_STEPS > 0
float auris_volumetricLight(sampler2D shadowtex1, mat4 shadowProjection, mat4 shadowModelView,
                             mat4 gbufferModelViewInverse, vec3 viewPos, vec2 fragCoord, float frame) {
    vec3 worldDir = normalize((gbufferModelViewInverse * vec4(viewPos, 0.0)).xyz);
    float maxDist = min(length(viewPos), 120.0); // early exit: nunca marcha além de 120 blocos

    float stepLen = maxDist / float(VL_STEPS);
    float jitter = temporalDither(fragCoord, frame);
    float t = stepLen * jitter;

    float accum = 0.0;
    for (int i = 0; i < VL_STEPS; i++) {
        vec3 samplePosView = normalize(viewPos) * t;
        vec3 samplePosWorld = (gbufferModelViewInverse * vec4(samplePosView, 1.0)).xyz;

        vec4 shadowClip = shadowProjection * shadowModelView * vec4(samplePosWorld, 1.0);
        shadowClip.xyz /= shadowClip.w;
        vec3 shadowScreen = shadowClip.xyz * 0.5 + 0.5;

        if (shadowScreen.x >= 0.0 && shadowScreen.x <= 1.0 && shadowScreen.y >= 0.0 && shadowScreen.y <= 1.0) {
            float shadowDepth = texture2D(shadowtex1, shadowScreen.xy).r;
            if (shadowScreen.z - 0.001 <= shadowDepth) {
                // Ponto iluminado: contribui pro acúmulo, atenuado pela distância
                accum += (1.0 / float(VL_STEPS)) * exp(-t * 0.01);
            }
        }
        t += stepLen;
    }

    return clamp(accum, 0.0, 1.0);
}
#endif

#endif // AURIS_VOLUMETRIC_INCLUDED
