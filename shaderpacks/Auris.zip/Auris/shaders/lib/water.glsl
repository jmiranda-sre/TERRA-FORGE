/*
 * ============================================================================
 *  AURIS SHADER — lib/water.glsl
 * ============================================================================
 *  Água NÃO usa geometria tesselada em nenhum profile (a missão proíbe
 *  isso explicitamente por custo) — as ondas vêm inteiramente de normal
 *  mapping proceduralizado (soma de senoides em movimento, "Gerstner
 *  barato" só na normal, não no vértice).
 *
 *  Ativo por profile:
 *    LOW    -> WATER_REFLECTION=1 (especular puro), sem refração perceptível.
 *    MEDIUM -> WATER_REFLECTION=2 (+ reflexo de céu), WATER_REFRACTION=1.
 *    HIGH   -> WATER_REFLECTION=3 (SSR com fallback pro céu), WATER_REFRACTION=2,
 *              WATER_PARALLAX opcional.
 *    ULTRA  -> tudo do High + CAUSTICS=1.
 * ============================================================================
 */

#ifndef AURIS_WATER_INCLUDED
#define AURIS_WATER_INCLUDED

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"

// Normal procedural da água — 3 oitavas de seno em direções diferentes,
// baratas o bastante pra rodar por pixel mesmo no Low (é só o pack de
// normal que muda de detalhe, não o número de octaves entre profiles,
// já que isso é O(1) e não escala o custo perceptivelmente).
vec3 auris_waterNormal(vec2 worldXZ, float time) {
    vec2 p1 = worldXZ * 0.6 + vec2(time * 0.35, time * 0.18);
    vec2 p2 = worldXZ * 1.7 - vec2(time * 0.22, time * 0.4);
    vec2 p3 = worldXZ * 4.1 + vec2(time * 0.55, -time * 0.31);

    float h = sin(p1.x) * cos(p1.y) * 0.5
            + sin(p2.x + p2.y) * 0.28
            + sin(p3.x * 1.3 - p3.y) * 0.09;

    // Derivadas parciais aproximadas (differença finita barata) pra normal
    float e = 0.15;
    float hx = sin(p1.x + e) * cos(p1.y) * 0.5 + sin(p2.x + e + p2.y) * 0.28 - h;
    float hz = sin(p1.x) * cos(p1.y + e) * 0.5 + sin(p2.x + p2.y + e) * 0.28 - h;

    return normalize(vec3(-hx, e * 2.0, -hz));
}

// ----------------------------------------------------------------------
// Reflexo — 4 variantes conforme WATER_REFLECTION, cada uma um caminho
// de código diferente (sem branch em runtime: profile define qual bloco
// existe no shader compilado).
// ----------------------------------------------------------------------
#if WATER_REFLECTION == 0
vec3 auris_waterReflection(vec3 viewDir, vec3 normal, vec3 skyColorSample, sampler2D colortexPrev, vec2 uv, mat4 proj) {
    return vec3(0.0); // Low mínimo: sem reflexo algum (mais barato que até o especular)
}
#elif WATER_REFLECTION == 1
vec3 auris_waterReflection(vec3 viewDir, vec3 normal, vec3 skyColorSample, sampler2D colortexPrev, vec2 uv, mat4 proj) {
    // Especular de Blinn-Phong contra o sol/lua apenas — sem amostrar
    // buffer nenhum, é literalmente 1 pow().
    return vec3(pow(max(dot(reflect(-viewDir, normal), normalize(viewDir + normal)), 0.0), 32.0));
}
#elif WATER_REFLECTION == 2
vec3 auris_waterReflection(vec3 viewDir, vec3 normal, vec3 skyColorSample, sampler2D colortexPrev, vec2 uv, mat4 proj) {
    // Especular + reflexo de céu constante (sem raymarch: assume-se que
    // tudo que a água reflete acima do horizonte é o gradiente de céu já
    // calculado, sem re-simular geometria refletida).
    float fresnel = pow(1.0 - max(dot(viewDir, normal), 0.0), 4.0);
    vec3 specular = vec3(pow(max(dot(reflect(-viewDir, normal), normalize(viewDir + normal)), 0.0), 32.0));
    return mix(specular, skyColorSample, fresnel * 0.6);
}
#else // WATER_REFLECTION == 3 (SSR, só High/Ultra)
vec3 auris_screenSpaceReflection(sampler2D colortexScene, sampler2D depthtex, vec3 viewPos, vec3 normal,
                                  mat4 projection, vec2 fragCoord, float frame) {
    vec3 reflectDir = reflect(normalize(viewPos), normal);
    vec3 rayPos = viewPos;
    float stepSize = 0.15;
    float jitter = temporalDither(fragCoord, frame);
    rayPos += reflectDir * stepSize * jitter; // jitter no primeiro passo (temporal, sem custo extra de sample)

    for (int i = 0; i < SSR_STEPS; i++) {
        rayPos += reflectDir * stepSize;
        vec4 clip = projection * vec4(rayPos, 1.0);
        clip.xyz /= clip.w;
        vec2 sUV = clip.xy * 0.5 + 0.5;

        if (sUV.x < 0.0 || sUV.x > 1.0 || sUV.y < 0.0 || sUV.y > 1.0) break; // early exit fora da tela

        float sceneDepth = texture2D(depthtex, sUV).r;
        float rayDepth = clip.z * 0.5 + 0.5;

        if (rayDepth > sceneDepth + 0.0008) {
            // Hit: encontrou geometria mais perto da câmera que o raio -> intersecção
            return texture2D(colortexScene, sUV).rgb;
        }
        stepSize *= 1.08; // passos crescentes = menos steps pra cobrir a mesma distância (early-exit friendly)
    }
    return vec3(-1.0); // sentinel: "sem hit", caller deve cair pro fallback de céu
}

vec3 auris_waterReflection(vec3 viewDir, vec3 normal, vec3 skyColorSample, sampler2D colortexPrev, vec2 uv, mat4 proj) {
    // Fallback simples pra manter a assinatura da função consistente entre
    // profiles; a chamada real de SSR (que precisa de mais uniforms) é
    // feita diretamente em gbuffers_water.fsh via auris_screenSpaceReflection.
    float fresnel = pow(1.0 - max(dot(viewDir, normal), 0.0), 4.0);
    return mix(vec3(0.02), skyColorSample, fresnel);
}
#endif

// ----------------------------------------------------------------------
// Refração — desloca o UV de amostragem do terreno/fundo por trás da água.
// ----------------------------------------------------------------------
#if WATER_REFRACTION == 0
vec2 auris_waterRefractionOffset(vec3 normal, float depthUnderwater) { return vec2(0.0); }
#elif WATER_REFRACTION == 1
vec2 auris_waterRefractionOffset(vec3 normal, float depthUnderwater) {
    return normal.xz * 0.02 * clamp(depthUnderwater, 0.0, 1.0);
}
#else // WATER_REFRACTION == 2 — aproximação de Snell (ângulo crítico simplificado)
vec2 auris_waterRefractionOffset(vec3 normal, float depthUnderwater) {
    float eta = 1.0 / 1.33; // ar -> água
    vec2 bend = normal.xz * eta;
    return bend * 0.045 * clamp(depthUnderwater, 0.0, 1.0);
}
#endif

// ----------------------------------------------------------------------
// Caustics — só Ultra. Projeta um padrão procedural (mesma família de
// senoides da normal, defasada) modulado pela profundidade da água.
// ----------------------------------------------------------------------
#if CAUSTICS == 1
float auris_causticsPattern(vec2 worldXZ, float time, float depthUnderwater) {
    vec2 p = worldXZ * 2.2;
    float c1 = sin(p.x + time * 0.8) * cos(p.y - time * 0.6);
    float c2 = sin(p.x * 1.7 - time * 0.5 + p.y);
    float caustic = pow(clamp(c1 * c2 + 0.6, 0.0, 1.0), 3.0);
    return caustic * exp(-depthUnderwater * 0.15); // atenua com profundidade
}
#endif

#endif // AURIS_WATER_INCLUDED
