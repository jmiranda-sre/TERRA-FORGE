/*
 * ============================================================================
 *  AURIS SHADER — lib/utils.glsl
 * ============================================================================
 *  Funções utilitárias genéricas: packing de normais, ruído, dithering
 *  temporal e helpers de espaço de tela <-> espaço de view.
 *  Ativo em: TODOS os profiles (funções aqui são O(1), sem custo por profile).
 * ============================================================================
 */

#ifndef AURIS_UTILS_INCLUDED
#define AURIS_UTILS_INCLUDED

// ----------------------------------------------------------------------
// Packing de normais (octahedron encoding) — 2 floats em vez de 3.
// Usado para economizar espaço no gbuffer (colortex de normais em RG16).
// ----------------------------------------------------------------------
vec2 octEncode(vec3 n) {
    n /= (abs(n.x) + abs(n.y) + abs(n.z));
    vec2 enc = n.xy;
    if (n.z < 0.0) {
        enc = (1.0 - abs(enc.yx)) * sign(enc.xy);
    }
    return enc * 0.5 + 0.5;
}

vec3 octDecode(vec2 f) {
    f = f * 2.0 - 1.0;
    vec3 n = vec3(f.x, f.y, 1.0 - abs(f.x) - abs(f.y));
    float t = clamp(-n.z, 0.0, 1.0);
    n.xy += mix(vec2(0.0), -sign(n.xy) * t, step(n.z, 0.0));
    return normalize(n);
}

// ----------------------------------------------------------------------
// Ruído barato — usado como semente para dithering temporal e para
// quebrar bandas em raymarching (jitter do ponto inicial do passo).
// ----------------------------------------------------------------------
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

// Interleaved Gradient Noise (Jorge Jimenez) — decorrelaciona bem entre
// pixels vizinhos, ideal pra dithering de raymarch sem padrão visível.
float interleavedGradientNoise(vec2 screenPos) {
    const vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
    return fract(magic.z * fract(dot(screenPos, magic.xy)));
}

// Matriz de Bayer 4x4 normalizada — usada no dithering de sombra/SSAO
// quando queremos um padrão fixo (não temporal) e barato.
float bayer4x4(vec2 fragCoord) {
    const float bayer[16] = float[16](
         0.0,  8.0,  2.0, 10.0,
        12.0,  4.0, 14.0,  6.0,
         3.0, 11.0,  1.0,  9.0,
        15.0,  7.0, 13.0,  5.0
    );
    ivec2 p = ivec2(mod(fragCoord, 4.0));
    return bayer[p.y * 4 + p.x] / 16.0;
}

// ----------------------------------------------------------------------
// Jitter temporal — cada técnica de raymarch usa isto para deslocar o
// primeiro passo por frame; combinado com acumulação temporal (ver
// composite2.fsh) isso substitui multi-sampling por frame.
// ----------------------------------------------------------------------
float temporalDither(vec2 fragCoord, float frame) {
    float ign = interleavedGradientNoise(fragCoord);
    // frameCounter avança 1 por frame; soma uma fração dourada pra
    // decorrelacionar entre frames sem repetir padrão a cada N frames.
    return fract(ign + 0.61803398875 * mod(frame, 256.0));
}

// ----------------------------------------------------------------------
// Reconstrução de posição em view-space a partir do depth buffer.
// ----------------------------------------------------------------------
vec3 viewSpaceFromDepth(vec2 uv, float depth, mat4 projInv) {
    vec4 clip = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 view = projInv * clip;
    return view.xyz / view.w;
}

// Luminância perceptual (Rec. 709) — usada em bloom threshold, exposure
// e color grading.
float luminance(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// Encode/decode simples de depth linear pra guardar em colortex de 16 bits
// quando precisamos reamostrar profundidade em passes de composite.
float linearizeDepth(float depth, float near, float far) {
    float z = depth * 2.0 - 1.0;
    return (2.0 * near * far) / (far + near - z * (far - near));
}

#endif // AURIS_UTILS_INCLUDED
