/*
 * ============================================================================
 *  AURIS SHADER — lib/lighting.glsl
 * ============================================================================
 *  Modelo de luz direta (Lambert + ambient) comum a todos os profiles,
 *  mais SSAO (samples controlados por SSAO_SAMPLES) e uma aproximação de
 *  GI barata (GI_APPROX, só High/Ultra).
 *
 *  Ativo por profile:
 *    LOW    -> Lambert + ambient constante. SSAO_SAMPLES=0 (função inteira
 *              vira um passthrough, sem loop nem sample extra).
 *    MEDIUM -> + SSAO_SAMPLES=4 (loop curto, hemisfério em screen-space).
 *    HIGH   -> + SSAO_SAMPLES=8 e GI_APPROX=1 (bounce a partir do buffer
 *              iluminado do frame anterior, reprojetado).
 *    ULTRA  -> SSAO_SAMPLES=16, GI_APPROX=1.
 * ============================================================================
 */

#ifndef AURIS_LIGHTING_INCLUDED
#define AURIS_LIGHTING_INCLUDED

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"

// Lambert simples + ambient mínimo (nunca deixa o lado escuro 100% preto,
// como no vanilla) — roda em TODO profile, é a base da iluminação direta.
vec3 auris_lambertLighting(vec3 albedo, vec3 normal, vec3 lightDir, vec3 lightColor,
                            float shadowFactor, vec3 ambientColor) {
    float NdotL = max(dot(normal, lightDir), 0.0);
    vec3 direct = albedo * lightColor * NdotL * shadowFactor;
    vec3 ambient = albedo * ambientColor;
    return direct + ambient;
}

// ----------------------------------------------------------------------
// SSAO — desligado por completo no Low (a função nem existe compilada,
// terrain.fsh testa `#if SSAO_SAMPLES > 0` antes de sequer chamá-la).
// ----------------------------------------------------------------------
#if SSAO_SAMPLES > 0
float auris_computeSSAO(sampler2D depthtex, vec2 uv, vec3 viewPos, vec3 normal,
                         mat4 projection, vec2 fragCoord, float frame) {
    float radius = 0.5;
    float bias = 0.02;
    float occlusion = 0.0;
    float ign = temporalDither(fragCoord, frame);

    for (int i = 0; i < SSAO_SAMPLES; i++) {
        // Amostra em hemisfério orientado pela normal, distribuída por
        // espiral áurea — decorrelaciona sem precisar de kernel pré-gerado.
        float fi = float(i) + ign;
        float theta = fi * 2.39996323; // golden angle
        float r = sqrt(fi / float(SSAO_SAMPLES)) * radius;
        vec3 sampleDir = normalize(vec3(cos(theta) * r, sin(theta) * r, 0.35 + 0.65 * (fi / float(SSAO_SAMPLES))));

        // Orienta o hemisfério pela normal do fragmento (aprox. TBN sem tangente real)
        vec3 up = abs(normal.z) < 0.99 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
        vec3 tangent = normalize(cross(up, normal));
        vec3 bitangent = cross(normal, tangent);
        vec3 samplePos = viewPos + (tangent * sampleDir.x + bitangent * sampleDir.y + normal * sampleDir.z);

        vec4 offset = projection * vec4(samplePos, 1.0);
        offset.xyz /= offset.w;
        offset.xy = offset.xy * 0.5 + 0.5;

        if (offset.x < 0.0 || offset.x > 1.0 || offset.y < 0.0 || offset.y > 1.0) continue;

        float sampleDepth = texture2D(depthtex, offset.xy).r;
        vec3 occluderViewPos = viewSpaceFromDepth(offset.xy, sampleDepth, inverse(projection));

        float rangeCheck = smoothstep(0.0, 1.0, radius / max(abs(viewPos.z - occluderViewPos.z), 0.0001));
        occlusion += (occluderViewPos.z >= samplePos.z + bias ? 1.0 : 0.0) * rangeCheck;
    }

    return 1.0 - clamp(occlusion / float(SSAO_SAMPLES), 0.0, 1.0);
}
#endif

// ----------------------------------------------------------------------
// GI aproximado — só compila em High/Ultra. Em vez de voxel-cone-tracing
// de verdade (caro demais pro orçamento do Auris), aproxima bounce-light
// reamostrando uma versão borrada e reprojetada do buffer já iluminado
// do frame anterior na direção da normal — um "screen-space bounce"
// bem barato (1 sample extra + o blur já é feito no composite2 pro
// bloom, então é reaproveitado, custo marginal quase zero).
// ----------------------------------------------------------------------
#if GI_APPROX == 1
vec3 auris_approxBounceLight(sampler2D previousLitBlurred, vec2 uv, vec3 normal, vec3 ambientColor) {
    vec2 bounceUV = clamp(uv + normal.xy * 0.05, 0.0, 1.0);
    vec3 bounce = texture2D(previousLitBlurred, bounceUV).rgb;
    return bounce * ambientColor * 0.35;
}
#endif

#endif // AURIS_LIGHTING_INCLUDED
