/*
 * ============================================================================
 *  AURIS SHADER — lib/clouds.glsl
 * ============================================================================
 *  CLOUDS_MODE 0 = off, 1 = camada 2D (plano único, barata), 2 = raymarch
 *  3D volumétrico (limitado por distância e por VL_STEPS-like budget).
 *
 *  Ativo por profile:
 *    LOW    -> CLOUDS_MODE=0 (desligado — a missão exige zero raymarch caro no Low)
 *    MEDIUM -> CLOUDS_MODE=1 (plano 2D só com ruído + sombra própria simples)
 *    HIGH   -> CLOUDS_MODE=2, poucos steps
 *    ULTRA  -> CLOUDS_MODE=2, mais steps + self-shadow das nuvens
 * ============================================================================
 */

#ifndef AURIS_CLOUDS_INCLUDED
#define AURIS_CLOUDS_INCLUDED

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"

#if CLOUDS_MODE >= 1
// Ruído de valor 2D barato (sem textura externa) — usado tanto no modo
// 2D quanto como densidade de base no raymarch 3D.
float auris_cloudNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float auris_cloudFbm(vec2 p) {
    float sum = 0.0;
    float amp = 0.5;
    for (int i = 0; i < 4; i++) {
        sum += auris_cloudNoise(p) * amp;
        p *= 2.02;
        amp *= 0.5;
    }
    return sum;
}
#endif

// ----------------------------------------------------------------------
// Modo 2D: intersecta o raio de view com um plano horizontal fixo em
// Y=CLOUD_HEIGHT e amostra FBM ali. Custo: 1 interseção de plano + 1 FBM
// (4 octaves) por pixel de céu — nada de marcha, nada de loop de steps.
// ----------------------------------------------------------------------
#if CLOUDS_MODE == 1
vec4 auris_clouds2D(vec3 rayOrigin, vec3 rayDir, float time, float cloudHeight) {
    if (rayDir.y <= 0.001) return vec4(0.0); // olhando pra baixo/horizonte: sem nuvem

    float t = (cloudHeight - rayOrigin.y) / rayDir.y;
    if (t < 0.0) return vec4(0.0);

    vec2 hitXZ = rayOrigin.xz + rayDir.xz * t;
    float density = auris_cloudFbm(hitXZ * 0.004 + vec2(time * 0.015, time * 0.008));
    density = smoothstep(0.55, 0.85, density);

    // Sombra própria simples: reamostra o FBM um pouco deslocado na
    // direção do sol (não é sombra volumétrica real, é o "flat shading"
    // clássico de nuvens em shaderpacks leves).
    vec2 shadowSampleXZ = hitXZ + vec2(30.0, 30.0);
    float shadowNoise = auris_cloudFbm(shadowSampleXZ * 0.004 + vec2(time * 0.015, time * 0.008));
    float selfShadow = mix(0.6, 1.0, smoothstep(0.4, 0.8, shadowNoise));

    vec3 cloudColor = vec3(1.0) * selfShadow;
    return vec4(cloudColor, density * 0.85);
}
#endif

// ----------------------------------------------------------------------
// Modo 3D: raymarch entre duas alturas (base/topo da camada de nuvem),
// com step count fixo e pequeno (VL_STEPS-like budget) e early-exit
// assim que a densidade acumulada satura (alpha ~1) ou o raio sai da
// camada. Só compila em High/Ultra.
// ----------------------------------------------------------------------
#if CLOUDS_MODE == 2

#if PROFILE >= 3
    #define AURIS_CLOUD_STEPS 24
#else
    #define AURIS_CLOUD_STEPS 10
#endif

float auris_cloudDensity3D(vec3 pos, float time) {
    float base = auris_cloudFbm(pos.xz * 0.003 + vec2(time * 0.015, time * 0.008));
    float detail = auris_cloudFbm(pos.xz * 0.02 + pos.y * 0.01 + vec2(time * 0.05, 0.0)) * 0.3;
    return smoothstep(0.5, 0.9, base + detail - abs(pos.y) * 0.002);
}

vec4 auris_clouds3D(vec3 rayOrigin, vec3 rayDir, float time, float baseHeight, float topHeight,
                     vec3 sunDir, vec2 fragCoord, float frame) {
    if (rayDir.y <= 0.001) return vec4(0.0);

    float tNear = (baseHeight - rayOrigin.y) / rayDir.y;
    float tFar  = (topHeight  - rayOrigin.y) / rayDir.y;
    if (tFar < 0.0) return vec4(0.0);
    tNear = max(tNear, 0.0);

    float stepLen = (tFar - tNear) / float(AURIS_CLOUD_STEPS);
    float jitter = temporalDither(fragCoord, frame);

    vec3 accumColor = vec3(0.0);
    float accumAlpha = 0.0;
    float t = tNear + stepLen * jitter;

    for (int i = 0; i < AURIS_CLOUD_STEPS; i++) {
        if (accumAlpha >= 0.98) break; // early-exit: já opaco, não vale marchar mais
        vec3 pos = rayOrigin + rayDir * t;
        float density = auris_cloudDensity3D(pos, time);

        if (density > 0.01) {
            // Luz direta aproximada: 1 sample extra de densidade na direção
            // do sol (não é lightmarch completo — apenas 1 passo, barato)
            float shadowDensity = auris_cloudDensity3D(pos + sunDir * 8.0, time);
            float lit = mix(1.0, 0.35, shadowDensity);

            float a = density * (1.0 - accumAlpha) * 0.35;
            accumColor += vec3(lit) * a;
            accumAlpha += a;
        }
        t += stepLen;
    }

    return vec4(accumColor, clamp(accumAlpha, 0.0, 1.0));
}
#endif

#endif // AURIS_CLOUDS_INCLUDED
