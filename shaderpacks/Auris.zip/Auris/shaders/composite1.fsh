/*
 * ============================================================================
 *  AURIS SHADER — composite1.fsh  (variante OVERWORLD — arquivo base)
 * ============================================================================
 *  Volumetric light (god rays, VL_STEPS) e nuvens (CLOUDS_MODE), ambos
 *  raymarch limitado por passo fixo e early-exit, com jitter temporal
 *  (ver lib/utils.glsl::temporalDither) pra permitir poucos steps sem
 *  banding perceptível — o denoising real acontece em composite2.fsh via
 *  reprojeção temporal.
 *
 *  Nether tem sua própria cópia em world-1/composite1.fsh (sem
 *  volumetric light solar — não há sol; usa glow ambiente do "teto" de
 *  bedrock/lava, mais barato). End tem world1/composite1.fsh (sem
 *  volumetric light nem nuvens — céu de vazio escuro).
 *
 *  Ativo por profile:
 *    LOW    -> VL_STEPS=0 e CLOUDS_MODE=0: este arquivo vira passthrough puro.
 *    MEDIUM -> VL_STEPS=8-12, CLOUDS_MODE=1 (plano 2D).
 *    HIGH   -> VL_STEPS=16-24, CLOUDS_MODE=2 (raymarch 3D, poucos steps).
 *    ULTRA  -> VL_STEPS=32, CLOUDS_MODE=2 com mais steps.
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"
#include "/lib/volumetric.glsl"
#include "/lib/clouds.glsl"

/* DRAWBUFFERS:0 */

varying vec2 texcoord;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
#if VL_STEPS > 0
uniform sampler2D shadowtex1;
uniform mat4 shadowProjection;
uniform mat4 shadowModelView;
#endif
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform int frameCounter;

void main() {
    vec4 sceneColor = texture2D(colortex0, texcoord);
    float depth = texture2D(depthtex0, texcoord).r;
    vec3 viewPos = viewSpaceFromDepth(texcoord, depth, gbufferProjectionInverse);
    vec3 result = sceneColor.rgb;

    #if VL_STEPS > 0
    float vl = auris_volumetricLight(shadowtex1, shadowProjection, shadowModelView,
                                      gbufferModelViewInverse, viewPos, gl_FragCoord.xy, float(frameCounter));
    vec3 sunGlowColor = vec3(1.0, 0.85, 0.6);
    result += sunGlowColor * vl * 0.25 * step(0.0, sunPosition.y);
    #endif

    #if CLOUDS_MODE > 0
    if (depth >= 0.9999) { // nuvens só se desenham por cima do céu, nunca por cima de terreno
        vec3 rayOrigin = vec3(0.0, cameraPosition.y, 0.0);
        vec3 rayDir = normalize((gbufferModelViewInverse * vec4(viewPos, 0.0)).xyz);

        #if CLOUDS_MODE == 1
        vec4 clouds = auris_clouds2D(rayOrigin, rayDir, frameTimeCounter, 190.0);
        #else
        vec4 clouds = auris_clouds3D(rayOrigin, rayDir, frameTimeCounter, 180.0, 230.0,
                                      normalize(sunPosition), gl_FragCoord.xy, float(frameCounter));
        #endif

        result = mix(result, clouds.rgb, clouds.a);
    }
    #endif

    gl_FragData[0] = vec4(result, sceneColor.a);
}
