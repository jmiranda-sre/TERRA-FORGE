/*
 * ============================================================================
 *  AURIS SHADER — gbuffers_entities.vsh
 * ============================================================================
 *  Vertex shader de entidades (mobs, jogadores, itens dropados). Mesmo
 *  modelo de luz do terreno, reaproveitando lib/lighting.glsl e
 *  lib/shadows.glsl — sem duplicar lógica.
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertexColor;
varying vec3 normal;
varying vec3 worldPos;
varying vec4 shadowClipPos;

uniform mat4 shadowProjection;
uniform mat4 shadowModelView;
uniform mat4 gbufferModelViewInverse;

void main() {
    gl_Position = ftransform();

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vertexColor = gl_Color; // já inclui o flash de dano (tint vermelho) aplicado pelo vanilla
    normal = normalize(gl_NormalMatrix * gl_Normal);

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    worldPos = (gbufferModelViewInverse * viewPos).xyz;
    shadowClipPos = shadowProjection * shadowModelView * vec4(worldPos, 1.0);
}
