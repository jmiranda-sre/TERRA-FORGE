/*
 * ============================================================================
 *  AURIS SHADER — deferred.fsh
 * ============================================================================
 *  Primeiro passe de tela cheia, executado depois que TODA a geometria
 *  opaca/translúcida já foi desenhada em colortex0/colortex1. Aqui
 *  aplicamos SSAO e o bounce-light aproximado (GI_APPROX) — ambos
 *  precisam ler pixels vizinhos, por isso não podem ser feitos dentro
 *  dos gbuffers_*.fsh (que só enxergam o próprio fragmento).
 *
 *  Em profile Low (SSAO_SAMPLES=0 e GI_APPROX=0), este arquivo inteiro
 *  vira um passthrough (`gl_FragData[0] = texture2D(colortex0, texcoord)`),
 *  sem nenhum sample extra nem custo de textura adicional — o
 *  `#if SSAO_SAMPLES > 0` corta o corpo pesado da função inteira.
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"
#include "/lib/lighting.glsl"

/* DRAWBUFFERS:0 */

varying vec2 texcoord;

uniform sampler2D colortex0; // cena lit (sem AO ainda)
uniform sampler2D colortex1; // normal empacotada + flag de material
uniform sampler2D depthtex0;
#if GI_APPROX == 1
uniform sampler2D colortex4; // histórico do frame anterior (bounce light), ver composite2.fsh
#endif
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform int frameCounter;

void main() {
    vec4 sceneColor = texture2D(colortex0, texcoord);
    vec4 packedNormalMat = texture2D(colortex1, texcoord);
    float materialFlag = packedNormalMat.b;

    // Céu (materialFlag não é setado pelo gbuffers_skybasic, então o
    // depth de fundo === 1.0 é o indicador confiável de "é céu").
    float depth = texture2D(depthtex0, texcoord).r;
    bool isSky = depth >= 0.9999;

    if (isSky) {
        gl_FragData[0] = sceneColor;
        return; // early-exit: céu nunca recebe SSAO/GI
    }

    vec3 normal = octDecode(packedNormalMat.rg);
    vec3 viewPos = viewSpaceFromDepth(texcoord, depth, gbufferProjectionInverse);

    vec3 result = sceneColor.rgb;

    #if SSAO_SAMPLES > 0
    float ao = auris_computeSSAO(depthtex0, texcoord, viewPos, normal, gbufferProjection, gl_FragCoord.xy, float(frameCounter));
    // Simplificação deliberada de custo/benefício: em vez de separar
    // ambient/direct em render targets distintos (o que exigiria mais um
    // colortex e mais bandwidth em todos os profiles, inclusive no Low),
    // o Auris aplica o AO sobre a cor final inteira, com uma força menor
    // (mix parcial) pra não escurecer demais a luz direta em cantos.
    // Ver resumo técnico para a justificativa completa desta troca.
    result *= mix(1.0, ao, 0.75);
    #endif

    #if GI_APPROX == 1
    vec3 bounce = auris_approxBounceLight(colortex4, texcoord, normal, vec3(0.5, 0.55, 0.65));
    result += bounce;
    #endif

    gl_FragData[0] = vec4(result, sceneColor.a);
}
