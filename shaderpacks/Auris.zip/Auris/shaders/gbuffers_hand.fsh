/*
 * ============================================================================
 *  AURIS SHADER — gbuffers_hand.fsh
 * ============================================================================
 *  Shading simplificado e propositalmente barato: sem consulta ao shadow
 *  map (o item na mão está sempre perto e a diferença visual de ter
 *  self-shadow correto não compensa 1 sample de shadow a mais por pixel
 *  em uma área pequena da tela, em nenhum profile).
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"

/* DRAWBUFFERS:01 */

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertexColor;
varying vec3 normal;

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform vec3 sunPosition;
uniform vec3 skyColor;

void main() {
    vec4 albedoTex = texture2D(texture, texcoord) * vertexColor;
    if (albedoTex.a < 0.05) discard;

    vec3 lightmapSample = texture2D(lightmap, lmcoord).rgb;
    vec3 ambientColor = skyColor * lightmapSample.g * 0.9 + vec3(1.0, 0.65, 0.35) * lightmapSample.r * lightmapSample.r * 1.4;

    float NdotL = max(dot(normal, normalize(sunPosition)), 0.0);
    vec3 litColor = albedoTex.rgb * (ambientColor + vec3(0.9, 0.87, 0.8) * NdotL * 0.6);

    gl_FragData[0] = vec4(litColor, albedoTex.a);
    gl_FragData[1] = vec4(octEncode(normal), 0.3 /* material flag: mão/item */, 1.0);
}
