/*
 * ============================================================================
 *  AURIS SHADER — world-1/composite.fsh  (override para o NETHER)
 * ============================================================================
 *  Usa o mesmo lib/fog.glsl (que, por sua vez, resolve pra
 *  world-1/lib/fog.glsl automaticamente — ver nota lá). A diferença
 *  deste arquivo pro composite.fsh do Overworld é só que não há
 *  sunPosition/rainStrength/worldTime relevantes aqui, então nem
 *  declaramos esses uniforms.
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"
#include "/lib/fog.glsl"

/* DRAWBUFFERS:0 */

varying vec2 texcoord;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 fogColor;
uniform int isEyeInWater;

void main() {
    vec4 sceneColor = texture2D(colortex0, texcoord);
    float depth = texture2D(depthtex0, texcoord).r;

    if (depth >= 0.9999) {
        gl_FragData[0] = sceneColor;
        return;
    }

    vec3 viewPos = viewSpaceFromDepth(texcoord, depth, gbufferProjectionInverse);
    float viewDistance = length(viewPos);
    vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;

    vec3 result;
    if (isEyeInWater == 1) {
        result = auris_applyWaterFog(sceneColor.rgb, vec3(0.35, 0.09, 0.06), viewDistance);
    } else {
        result = auris_applyOverworldFog(sceneColor.rgb, fogColor, viewDistance, worldPos.y, 0.0, 1.0);
    }

    gl_FragData[0] = vec4(result, sceneColor.a);
}
