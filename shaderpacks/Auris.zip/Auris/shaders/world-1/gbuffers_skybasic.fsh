/*
 * ============================================================================
 *  AURIS SHADER — world-1/gbuffers_skybasic.fsh  (override para o NETHER)
 * ============================================================================
 *  O Nether não tem sol/lua/ciclo dia-noite — o "céu" (na verdade o void
 *  acima da bedrock) é um teto sólido de cor quente/avermelhada, sem
 *  gradiente baseado em sunDir (não existe sunDir relevante lá).
 * ============================================================================
 */
#version 120

/* DRAWBUFFERS:0 */

varying vec3 viewDir;

void main() {
    // Leve variação por altura do vetor de visão só pra não ficar uma
    // cor 100% chapada — sem depender de nenhum uniform de sol/lua.
    float verticalBlend = clamp(viewDir.y * 0.5 + 0.5, 0.0, 1.0);
    vec3 netherAmbientLow  = vec3(0.10, 0.02, 0.01);
    vec3 netherAmbientHigh = vec3(0.20, 0.05, 0.02);
    vec3 sky = mix(netherAmbientLow, netherAmbientHigh, verticalBlend);

    gl_FragData[0] = vec4(sky, 1.0);
}
