/*
 * ============================================================================
 *  AURIS SHADER — world-1/lib/fog.glsl  (override para o NETHER)
 * ============================================================================
 *  O Iris resolve `#include "/lib/fog.glsl"` para ESTE arquivo sempre que
 *  o jogador está no Nether, em vez do arquivo em shaders/lib/fog.glsl —
 *  o mesmo mecanismo de pasta por dimensão (world-1 = Nether, world1 =
 *  End) que se aplica aos programas de shader também se aplica a includes.
 *  Isso permite fog completamente diferente sem NENHUM `#ifdef NETHER`
 *  em runtime — cada dimensão literalmente linka um shader diferente.
 * ============================================================================
 */

#ifndef AURIS_FOG_INCLUDED
#define AURIS_FOG_INCLUDED

// Nether: névoa densa, avermelhada/alaranjada, quase não depende de
// altura (o Nether não tem "céu" pra rarefazer a névoa contra) — o que
// dá a sensação de neblina sufocante característica da dimensão.
vec3 auris_applyOverworldFog(vec3 color, vec3 skyFogColor, float viewDistance,
                              float fragWorldHeight, float rainStrength,
                              float timeOfDayFactor) {
    float density = 0.018; // mais denso que o Overworld — não há chuva/timeOfDay no Nether
    float fogFactor = 1.0 - exp(-density * viewDistance);
    fogFactor = clamp(fogFactor, 0.0, 1.0);

    vec3 netherFogColor = mix(skyFogColor, vec3(0.45, 0.12, 0.05), 0.55);
    return mix(color, netherFogColor, fogFactor);
}

vec3 auris_applyWaterFog(vec3 color, vec3 waterAbsorb, float travelDistance) {
    // Água é rara/inexistente no Nether (evapora); mantido só por
    // segurança de compilação caso algum mod adicione água líquida lá.
    vec3 transmittance = exp(-waterAbsorb * travelDistance);
    return mix(vec3(0.05, 0.02, 0.01), color, transmittance);
}

#endif // AURIS_FOG_INCLUDED
