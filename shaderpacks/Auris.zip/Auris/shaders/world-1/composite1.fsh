/*
 * ============================================================================
 *  AURIS SHADER — world-1/composite1.fsh  (override para o NETHER)
 * ============================================================================
 *  Sem sol visível e sem nuvens no Nether: este arquivo é um passthrough
 *  puro, mesmo em High/Ultra. Isso é economia de performance real e
 *  gratuita que o Overworld não tem — todo o custo de VL_STEPS e
 *  CLOUDS_MODE dos profiles altos simplesmente não existe nesta
 *  dimensão, porque o override de pasta troca o programa inteiro por um
 *  mais barato, em vez de manter os `#if` e testá-los em runtime.
 * ============================================================================
 */
#version 120

varying vec2 texcoord;

uniform sampler2D colortex0;

void main() {
    gl_FragData[0] = texture2D(colortex0, texcoord);
}
