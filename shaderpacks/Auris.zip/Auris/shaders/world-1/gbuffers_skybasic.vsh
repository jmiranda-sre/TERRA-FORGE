/*
 * ============================================================================
 *  AURIS SHADER — world-1/gbuffers_skybasic.vsh  (override para o NETHER)
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"

varying vec3 viewDir;

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;

void main() {
    gl_Position = ftransform();
    vec4 view = gbufferProjectionInverse * gl_Position;
    viewDir = normalize((gbufferModelViewInverse * vec4(view.xyz / view.w, 0.0)).xyz);
}
