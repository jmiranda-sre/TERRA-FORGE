/*
 * ============================================================================
 *  AURIS SHADER — gbuffers_water.fsh
 * ============================================================================
 *  Reflexo, refração, parallax e caustics conforme WATER_REFLECTION /
 *  WATER_REFRACTION / WATER_PARALLAX / CAUSTICS (ver lib/water.glsl para a
 *  tabela de o que ativa em cada profile).
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"
#include "/lib/shadows.glsl"
#include "/lib/lighting.glsl"
#include "/lib/water.glsl"

/* DRAWBUFFERS:01 */

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertexColor;
varying vec3 normal;
varying vec3 worldPos;
varying vec3 viewPos;
varying vec4 shadowClipPos;
varying float isWater;

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex1;
uniform sampler2D depthtex1;   // depth só de opacos (sem translúcidos) — pra refração
uniform sampler2D colortex0;   // cena já renderizada (opacos) até aqui — pra refração/SSR
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 skyColor;
uniform float frameTimeCounter;
uniform int frameCounter;
uniform float viewWidth;
uniform float viewHeight;

void main() {
    vec2 fragCoord = gl_FragCoord.xy;
    vec2 screenUV = fragCoord / vec2(viewWidth, viewHeight);

    vec3 waveNormal = normal;
    if (isWater > 0.5) {
        vec3 procNormal = auris_waterNormal(worldPos.xz, frameTimeCounter);
        // Combina a normal geométrica (aponta pra cima) com a normal
        // procedural das ondas, mantendo o plano geral do bloco de água.
        waveNormal = normalize(mix(normal, procNormal, 0.9));
    }

    vec3 viewDir = normalize(-viewPos);

    // ---- Refração: desloca o UV de amostragem do fundo ----
    float opaqueDepth = texture2D(depthtex1, screenUV).r;
    vec3 opaqueViewPos = viewSpaceFromDepth(screenUV, opaqueDepth, gbufferProjectionInverse);
    float depthUnderwater = length(opaqueViewPos - viewPos);

    #if WATER_REFRACTION > 0
    vec2 refractOffset = isWater > 0.5 ? auris_waterRefractionOffset(waveNormal, depthUnderwater) : vec2(0.0);
    #else
    vec2 refractOffset = vec2(0.0);
    #endif

    vec2 refractedUV = clamp(screenUV + refractOffset, 0.001, 0.999);
    vec3 behindColor = texture2D(colortex0, refractedUV).rgb;

    // ---- Reflexo ----
    #if WATER_REFLECTION == 3
    vec3 reflection = auris_screenSpaceReflection(colortex0, depthtex1, viewPos, waveNormal,
                                                   gbufferProjection, fragCoord, float(frameCounter));
    if (reflection.r < 0.0) {
        // Sentinel de "sem hit": fallback pro reflexo de céu simples
        float fresnel = pow(1.0 - max(dot(viewDir, waveNormal), 0.0), 4.0);
        reflection = mix(vec3(0.02), skyColor, fresnel);
    }
    #else
    vec3 reflection = auris_waterReflection(viewDir, waveNormal, skyColor, colortex0, screenUV, gbufferProjection);
    #endif

    float fresnel = clamp(pow(1.0 - max(dot(viewDir, waveNormal), 0.0), 5.0), 0.02, 0.97);

    vec4 albedoTex = texture2D(texture, texcoord) * vertexColor;
    vec3 waterColor = mix(behindColor * albedoTex.rgb * 1.05, reflection, isWater > 0.5 ? fresnel : 0.0);

    // Blocos translúcidos que não são água (vidro colorido, gelo) usam o
    // caminho simples de albedo * fundo, sem reflexo especular de água.
    vec3 finalColor = isWater > 0.5 ? waterColor : mix(behindColor, albedoTex.rgb, albedoTex.a);

    #if CAUSTICS == 1
    if (isWater > 0.5) {
        float caustic = auris_causticsPattern(worldPos.xz, frameTimeCounter, depthUnderwater);
        finalColor += caustic * 0.15 * (1.0 - fresnel);
    }
    #endif

    float outAlpha = isWater > 0.5 ? max(albedoTex.a, 0.55) : albedoTex.a;

    gl_FragData[0] = vec4(finalColor, outAlpha);
    gl_FragData[1] = vec4(octEncode(waveNormal), 1.0 /* material flag: 1 = água/translúcido */, 1.0);
}
