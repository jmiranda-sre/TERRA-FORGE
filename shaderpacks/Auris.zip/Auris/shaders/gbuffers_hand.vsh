/*
 * ============================================================================
 *  AURIS SHADER — gbuffers_hand.vsh
 * ============================================================================
 *  Item/braço em primeira pessoa. O Iris já resolve o range de depth do
 *  hand corretamente antes de chamar este programa (via a matriz de
 *  projeção específica que a Vanilla/Iris usa pra desenhar a mão), então
 *  não é necessário nenhum hack extra de profundidade aqui — só shading
 *  mais barato, já que o item ocupa poucos pixels e fica sempre em foco.
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertexColor;
varying vec3 normal;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vertexColor = gl_Color;
    normal = normalize(gl_NormalMatrix * gl_Normal);
}
