/*
 * ============================================================================
 *  AURIS SHADER — gbuffers_water.vsh
 * ============================================================================
 *  Vertex shader de água e outros blocos translúcidos. SEM geometria
 *  tesselada (a mission proíbe água tesselada cara) — a superfície
 *  continua sendo o quad plano do vanilla; toda a "onda" é normal mapping
 *  procedural calculado no fragment shader via lib/water.glsl.
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertexColor;
varying vec3 normal;
varying vec3 worldPos;
varying vec3 viewPos;
varying vec4 shadowClipPos;
varying float isWater; // mc_Entity.x distingue água de outros translúcidos (vidro, gelo)

uniform mat4 shadowProjection;
uniform mat4 shadowModelView;
uniform mat4 gbufferModelViewInverse;

attribute vec3 mc_Entity;

void main() {
    gl_Position = ftransform();

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vertexColor = gl_Color;
    normal = normalize(gl_NormalMatrix * gl_Normal);

    viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
    worldPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    shadowClipPos = shadowProjection * shadowModelView * vec4(worldPos, 1.0);

    // mc_Entity.x é remapeado no shaders.properties (block.X = mc_Entity id)
    // pra identificar água (ver shaders.properties, bloco "block.*").
    isWater = (mc_Entity.x > 0.5) ? 1.0 : 0.0;
}
