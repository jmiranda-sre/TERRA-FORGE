/*
 * ============================================================================
 *  AURIS SHADER — shadow.vsh
 * ============================================================================
 *  Vertex shader do shadow pass (todo o mapa de sombra do Auris, em todas
 *  as dimensões, passa por aqui — Nether/End só usam isto quando o
 *  jogador está sob luz artificial equivalente; ainda assim o pass em si
 *  é o mesmo, só shadowLightPosition muda). Aplica a distorção de
 *  projeção (SHADOW_DISTORT) — ver lib/shadows.glsl para a explicação da
 *  pseudo-cascata.
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/shadows.glsl"

varying vec2 texcoord;
varying vec4 vertexColor;

attribute vec3 mc_Entity;
varying float blockId;

void main() {
    vec4 clipPos = gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex;

    #if SHADOW_DISTORT == 1
    clipPos.xyz = auris_distortShadowClip(clipPos.xyz);
    #endif

    gl_Position = clipPos;

    texcoord = gl_MultiTexCoord0.xy;
    vertexColor = gl_Color;
    blockId = mc_Entity.x;
}
