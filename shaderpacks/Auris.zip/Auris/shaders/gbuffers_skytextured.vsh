/*
 * ============================================================================
 *  AURIS SHADER — gbuffers_skytextured.vsh  (variante OVERWORLD)
 * ============================================================================
 *  Sol, lua e estrelas (texturas vanilla). Nether e End não chamam este
 *  programa com conteúdo visível (sem sol/lua) — ver os overrides em
 *  world-1/ e world1/, que escondem esses elementos.
 * ============================================================================
 */
#version 120

varying vec2 texcoord;
varying vec4 vertexColor;

void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    vertexColor = gl_Color;
}
