/*
 * ============================================================================
 *  AURIS SHADER — gbuffers_terrain.vsh
 * ============================================================================
 *  Vertex shader do terreno (blocos sólidos e cutout). Ativo em TODOS os
 *  profiles — o que muda entre profiles é o que o .fsh faz com os dados
 *  aqui calculados, não a geometria em si (sem tesselação em nenhum profile).
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"

varying vec2 texcoord;
varying vec2 lmcoord;      // lightmap coord (block light / sky light do vanilla)
varying vec4 vertexColor;  // tint vanilla (folhas, grama, água colorida por bioma)
varying vec3 normal;
varying vec3 worldPos;
varying vec4 shadowClipPos;

uniform mat4 shadowProjection;
uniform mat4 shadowModelView;
uniform mat4 gbufferModelViewInverse;

void main() {
    gl_Position = ftransform();

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vertexColor = gl_Color;
    normal = normalize(gl_NormalMatrix * gl_Normal);

    // Posição em world-space (aprox., relativa à câmera — suficiente pra
    // fog e pra reamostrar o shadow map; não precisamos da posição
    // absoluta do mundo, só relativa, o que evita perda de precisão em
    // coordenadas grandes).
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    worldPos = (gbufferModelViewInverse * viewPos).xyz;

    shadowClipPos = shadowProjection * shadowModelView * vec4(worldPos, 1.0);
}
