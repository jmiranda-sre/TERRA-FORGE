/*
 * ============================================================================
 *  AURIS SHADER — world1/composite.fsh  (override para o END)
 * ============================================================================
 *  Além do fog violeta (via world1/lib/fog.glsl), aplica um PISO mínimo
 *  de luz ambiente sobre a cena: como o End não tem sol/lua, skyColor
 *  vem quase preto do jogo, e sem esse piso o terreno ficaria escuro
 *  demais fora do alcance das ilhas de âmbar/end rods. Isso é o
 *  "tratamento de fog e ambient light específico" pedido na missão —
 *  feito aqui, e não em gbuffers_terrain.fsh, pra não adicionar nenhum
 *  `#ifdef` de dimensão nos arquivos de gbuffer (que são compartilhados
 *  entre as 3 dimensões).
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"
#include "/lib/fog.glsl"

/* DRAWBUFFERS:0 */

varying vec2 texcoord;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 fogColor;

const vec3 AURIS_END_AMBIENT_FLOOR = vec3(0.05, 0.045, 0.07);

void main() {
    vec4 sceneColor = texture2D(colortex0, texcoord);
    float depth = texture2D(depthtex0, texcoord).r;

    if (depth >= 0.9999) {
        gl_FragData[0] = sceneColor;
        return;
    }

    vec3 viewPos = viewSpaceFromDepth(texcoord, depth, gbufferProjectionInverse);
    float viewDistance = length(viewPos);
    vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;

    vec3 litFloor = max(sceneColor.rgb, AURIS_END_AMBIENT_FLOOR);
    vec3 result = auris_applyOverworldFog(litFloor, fogColor, viewDistance, worldPos.y, 0.0, 1.0);

    gl_FragData[0] = vec4(result, sceneColor.a);
}
