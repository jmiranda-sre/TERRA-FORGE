/*
 * ============================================================================
 *  AURIS SHADER — world1/gbuffers_skybasic.vsh  (override para o END)
 * ============================================================================
 */
#version 120

varying vec3 viewDir;

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;

void main() {
    gl_Position = ftransform();
    vec4 view = gbufferProjectionInverse * gl_Position;
    viewDir = normalize((gbufferModelViewInverse * vec4(view.xyz / view.w, 0.0)).xyz);
}
