/*
 * ============================================================================
 *  AURIS SHADER — world1/lib/fog.glsl  (override para o END)
 * ============================================================================
 *  Ver a explicação do mecanismo de override em world-1/lib/fog.glsl —
 *  aqui o mesmo princípio aplica-se ao End (world1 = dimensão 1).
 * ============================================================================
 */

#ifndef AURIS_FOG_INCLUDED
#define AURIS_FOG_INCLUDED

// End: névoa leve, violeta/acinzentada, sem variação de altura relevante
// (o End é um vazio quase infinito — não há "chão de referência" pra
// atenuar a névoa por altura como no Overworld).
vec3 auris_applyOverworldFog(vec3 color, vec3 skyFogColor, float viewDistance,
                              float fragWorldHeight, float rainStrength,
                              float timeOfDayFactor) {
    float density = 0.006;
    float fogFactor = 1.0 - exp(-density * viewDistance);
    fogFactor = clamp(fogFactor, 0.0, 1.0);

    vec3 endFogColor = vec3(0.08, 0.04, 0.12);
    return mix(color, endFogColor, fogFactor);
}

vec3 auris_applyWaterFog(vec3 color, vec3 waterAbsorb, float travelDistance) {
    // Sem água líquida nativa no End; mantido por segurança de compilação.
    vec3 transmittance = exp(-waterAbsorb * travelDistance);
    return mix(vec3(0.03, 0.02, 0.05), color, transmittance);
}

#endif // AURIS_FOG_INCLUDED
