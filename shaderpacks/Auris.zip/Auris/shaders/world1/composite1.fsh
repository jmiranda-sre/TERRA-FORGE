/*
 * ============================================================================
 *  AURIS SHADER — world1/composite1.fsh  (override para o END)
 * ============================================================================
 *  Mesmo raciocínio do world-1/composite1.fsh (Nether): sem sol, sem
 *  nuvens, então este passe é passthrough puro em qualquer profile,
 *  economizando o custo de VL_STEPS/CLOUDS_MODE nesta dimensão.
 * ============================================================================
 */
#version 120

varying vec2 texcoord;

uniform sampler2D colortex0;

void main() {
    gl_FragData[0] = texture2D(colortex0, texcoord);
}
