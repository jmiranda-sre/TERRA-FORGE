/*
 * ============================================================================
 *  AURIS SHADER — world1/gbuffers_skybasic.fsh  (override para o END)
 * ============================================================================
 *  O End não tem sol/lua/ciclo dia-noite: o vazio ao redor é quase preto
 *  com um leve tom violeta, sem gradiente baseado em sunDir.
 * ============================================================================
 */
#version 120

/* DRAWBUFFERS:0 */

varying vec3 viewDir;

void main() {
    float verticalBlend = clamp(viewDir.y * 0.5 + 0.5, 0.0, 1.0);
    vec3 endVoidLow  = vec3(0.015, 0.008, 0.02);
    vec3 endVoidHigh = vec3(0.05, 0.02, 0.07);
    vec3 sky = mix(endVoidLow, endVoidHigh, verticalBlend);

    gl_FragData[0] = vec4(sky, 1.0);
}
