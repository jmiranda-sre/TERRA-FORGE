/*
 * ============================================================================
 *  AURIS SHADER — gbuffers_entities.fsh
 * ============================================================================
 *  Ativo em: todos os profiles. SHADOW_ENTITIES controla se entidades
 *  recebem/projetam sombra (desligar economiza os draw calls extras do
 *  shadow pass para mobs, útil no Low com muitos mobs na tela).
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"
#include "/lib/shadows.glsl"
#include "/lib/lighting.glsl"

/* DRAWBUFFERS:01 */

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertexColor;
varying vec3 normal;
varying vec3 worldPos;
varying vec4 shadowClipPos;

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex1;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 skyColor;
uniform int frameCounter;

void main() {
    vec4 albedoTex = texture2D(texture, texcoord) * vertexColor;
    if (albedoTex.a < 0.05) discard;

    vec2 fragCoord = gl_FragCoord.xy;
    vec3 shadowLightDir = normalize(sunPosition.y > 0.0 ? sunPosition : moonPosition);
    vec3 lightColorDirect = mix(vec3(1.0, 0.96, 0.87), vec3(0.35, 0.4, 0.55), step(sunPosition.y, 0.0));

    float shadow = 1.0;
    #if SHADOW_ENTITIES == 1
    float NdotL = max(dot(normal, shadowLightDir), 0.0);
    float bias = mix(0.002, 0.0006, NdotL);
    vec3 shadowScreenPos = auris_distortShadowClip(shadowClipPos.xyz / shadowClipPos.w) * 0.5 + 0.5;
    if (shadowScreenPos.x >= 0.0 && shadowScreenPos.x <= 1.0 && shadowScreenPos.y >= 0.0 && shadowScreenPos.y <= 1.0) {
        shadow = auris_shadowFactor(shadowtex1, shadowScreenPos, bias, fragCoord, float(frameCounter));
    }
    #endif

    vec3 lightmapSample = texture2D(lightmap, lmcoord).rgb;
    vec3 ambientColor = skyColor * lightmapSample.g * 0.9 + vec3(1.0, 0.65, 0.35) * lightmapSample.r * lightmapSample.r * 1.4;

    vec3 litColor = auris_lambertLighting(albedoTex.rgb, normal, shadowLightDir, lightColorDirect, shadow, ambientColor);

    gl_FragData[0] = vec4(litColor, albedoTex.a);
    gl_FragData[1] = vec4(octEncode(normal), 0.2 /* material flag: entidade */, 1.0);
}
