/*
 * ============================================================================
 *  AURIS SHADER — gbuffers_skybasic.fsh  (variante OVERWORLD — arquivo base)
 * ============================================================================
 *  Gradiente procedural de céu do Overworld (lib/sky.glsl). Ativo em
 *  todos os profiles — o gradiente em si é O(1); a diferença entre
 *  profiles aparece em composite1.fsh, onde as nuvens 2D/3D são
 *  desenhadas por cima do que este arquivo escreve.
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/sky.glsl"

/* DRAWBUFFERS:0 */

varying vec3 viewDir;

uniform vec3 sunPosition;
uniform float rainStrength;
uniform float worldTime;

void main() {
    vec3 sunDir = normalize(sunPosition);
    float timeOfDay = auris_timeOfDayFactor(fract(worldTime / 24000.0));

    vec3 sky = auris_skyGradient(viewDir, sunDir, timeOfDay, rainStrength);

    gl_FragData[0] = vec4(sky, 1.0);
}
