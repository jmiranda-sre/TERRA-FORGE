/*
 * ============================================================================
 *  AURIS SHADER — shadow.fsh
 * ============================================================================
 *  Cutout de folhagem/grades no shadow pass (senão sombras de blocos
 *  transparentes ficariam sólidas). Em COLORED_SHADOWS=1 (High/Ultra),
 *  também escreve a cor do bloco translúcido em shadowcolor0, lida depois
 *  por auris_coloredShadowTint() em lib/shadows.glsl.
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"

#if COLORED_SHADOWS == 1
/* DRAWBUFFERS:0 */
#endif

varying vec2 texcoord;
varying vec4 vertexColor;
varying float blockId;

uniform sampler2D texture;

void main() {
    vec4 tex = texture2D(texture, texcoord) * vertexColor;

    if (tex.a < 0.1) {
        discard; // folhas/grades/flores: não bloqueiam luz (cutout)
    }

    #if COLORED_SHADOWS == 1
    // Blocos translúcidos (vidro, água rasa) escrevem sua cor com alpha
    // reduzido em shadowcolor0; blocos opacos escrevem branco opaco
    // (bloqueiam 100% da luz, sem tingir).
    if (tex.a < 0.98) {
        gl_FragData[0] = vec4(tex.rgb, tex.a * 0.6);
    } else {
        gl_FragData[0] = vec4(1.0);
    }
    #endif
}
