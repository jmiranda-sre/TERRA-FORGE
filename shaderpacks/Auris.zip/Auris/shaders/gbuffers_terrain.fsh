/*
 * ============================================================================
 *  AURIS SHADER — gbuffers_terrain.fsh
 * ============================================================================
 *  Shading do terreno: forward-shaded (não é G-buffer completo com PBR —
 *  decisão deliberada de custo/benefício, ver resumo técnico). Escreve:
 *    colortex0 -> cor final (direta + shadow + ambient), SEM AO ainda
 *                 (AO é aplicado depois, em deferred.fsh, como pós-processo
 *                 de tela cheia, pois SSAO precisa dos vizinhos de tela).
 *    colortex1 -> normal empacotada (RG) + flag de material (B).
 *  Ativo em: todos os profiles. O que varia por profile é só a resolução
 *  do shadow map, o modo de PCF/PCSS e se COLORED_SHADOWS está ligado —
 *  tudo isso já é resolvido dentro de auris_shadowFactor / lib/shadows.glsl,
 *  este arquivo não precisa de `#if` de profile diretamente.
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"
#include "/lib/shadows.glsl"
#include "/lib/lighting.glsl"

/* DRAWBUFFERS:01 */

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vertexColor;
varying vec3 normal;
varying vec3 worldPos;
varying vec4 shadowClipPos;

uniform sampler2D texture;   // textura do bloco (atlas)
uniform sampler2D lightmap;  // lightmap vanilla (block light + sky light)
uniform sampler2D shadowtex1;
#if COLORED_SHADOWS == 1
uniform sampler2D shadowtex0;
uniform sampler2D shadowcolor0;
#endif

uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform int frameCounter;

void main() {
    vec4 albedoTex = texture2D(texture, texcoord) * vertexColor;
    if (albedoTex.a < 0.1) discard; // cutout (folhas, grades, flores) — early discard antes de qualquer luz

    vec2 fragCoord = gl_FragCoord.xy;

    // Escolhe sol ou lua como a luz "direta" ativa (sunPosition/moonPosition
    // já vêm normalizados e mutuamente exclusivos do lado certo do ciclo
    // pelo próprio Iris).
    vec3 shadowLightDir = normalize(sunPosition.y > 0.0 ? sunPosition : moonPosition);
    vec3 lightColorDirect = mix(vec3(1.0, 0.96, 0.87), vec3(0.35, 0.4, 0.55), step(sunPosition.y, 0.0));

    // Bias de sombra escalado pela inclinação — reduz peter-panning sem
    // precisar de um bias fixo alto (que causaria light leaking).
    float NdotL = max(dot(normal, shadowLightDir), 0.0);
    float bias = mix(0.0018, 0.0004, NdotL);

    vec3 shadowScreenPos = auris_distortShadowClip(shadowClipPos.xyz / shadowClipPos.w) * 0.5 + 0.5;
    float shadow = 1.0;
    if (shadowScreenPos.x >= 0.0 && shadowScreenPos.x <= 1.0 && shadowScreenPos.y >= 0.0 && shadowScreenPos.y <= 1.0) {
        shadow = auris_shadowFactor(shadowtex1, shadowScreenPos, bias, fragCoord, float(frameCounter));
    }

    #if COLORED_SHADOWS == 1
    vec3 shadowTint = vec3(1.0);
    if (shadowScreenPos.x >= 0.0 && shadowScreenPos.x <= 1.0 && shadowScreenPos.y >= 0.0 && shadowScreenPos.y <= 1.0) {
        shadowTint = auris_coloredShadowTint(shadowcolor0, shadowtex0, shadowtex1, shadowScreenPos);
    }
    lightColorDirect *= shadowTint;
    #endif

    // Lightmap vanilla: canal R = block light (tochas etc.), canal G = sky light.
    vec3 lightmapSample = texture2D(lightmap, lmcoord).rgb;
    vec3 ambientColor = skyColor * lightmapSample.g * 0.9 + vec3(1.0, 0.65, 0.35) * lightmapSample.r * lightmapSample.r * 1.4;

    vec3 litColor = auris_lambertLighting(albedoTex.rgb, normal, shadowLightDir, lightColorDirect, shadow, ambientColor);

    gl_FragData[0] = vec4(litColor, albedoTex.a);
    gl_FragData[1] = vec4(octEncode(normal), 0.0 /* material flag: 0 = terreno opaco */, 1.0);
}
