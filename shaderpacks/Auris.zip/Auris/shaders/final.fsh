/*
 * ============================================================================
 *  AURIS SHADER — final.fsh
 * ============================================================================
 *  Último passe: tone mapping (sempre ativo, não é opcional — sem ele o
 *  bloom/HDR estoura em branco), color grading, DOF e motion blur
 *  (ambos opcionais, só High/Ultra), e auto-exposure (Ultra).
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"

varying vec2 texcoord;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform float viewWidth;
uniform float viewHeight;
uniform float centerDepthSmooth; // fornecido pelo Iris quando gaussianSamples/centerDepth está habilitado
uniform int frameCounter;

// ACES filmic tonemap aproximado (Narkowicz) — barato (sem LUT, sem
// textura extra), roda em todo profile.
vec3 auris_tonemapACES(vec3 color) {
    const float a = 2.51, b = 0.03, c = 2.43, d = 0.59, e = 0.14;
    return clamp((color * (a * color + b)) / (color * (c * color + d) + e), 0.0, 1.0);
}

vec3 auris_colorGrade(vec3 color) {
    #if COLOR_GRADE_STRENGTH == 0
    return color;
    #else
        #if COLOR_GRADE_STRENGTH == 1
        float strength = 0.15;
        #else
        float strength = 0.35;
        #endif
    // Leve dessaturação nas sombras + realce quente nas altas luzes —
    // dá uma "assinatura" visual ao Auris sem custar mais que 2 mix().
    float lum = luminance(color);
    vec3 shadowsTint = mix(color, vec3(lum), 0.2);
    vec3 highlightsTint = color * vec3(1.05, 1.0, 0.92);
    vec3 graded = mix(shadowsTint, highlightsTint, smoothstep(0.2, 0.8, lum));
    return mix(color, graded, strength);
    #endif
}

#if DOF_ENABLED == 1
vec3 auris_depthOfField(vec2 uv, float centerDepth) {
    float texel = 1.0 / viewWidth;
    float fragDepth = texture2D(depthtex0, uv).r;
    float coc = clamp(abs(fragDepth - centerDepth) * 220.0, 0.0, 1.0); // circle of confusion aproximado

    if (coc < 0.02) return texture2D(colortex0, uv).rgb;

    vec3 sum = vec3(0.0);
    float count = 0.0;
    const int SAMPLES = 8;
    for (int i = 0; i < SAMPLES; i++) {
        float angle = (float(i) / float(SAMPLES)) * AURIS_TAU;
        vec2 o = vec2(cos(angle), sin(angle)) * texel * coc * 6.0;
        sum += texture2D(colortex0, uv + o).rgb;
        count += 1.0;
    }
    return sum / count;
}
#endif

#if MOTION_BLUR_ENABLED == 1
vec3 auris_motionBlur(vec2 uv) {
    float depth = texture2D(depthtex0, uv).r;
    if (depth >= 0.9999) return texture2D(colortex0, uv).rgb;

    vec3 viewPos = viewSpaceFromDepth(uv, depth, gbufferProjectionInverse);
    vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
    vec3 worldPosPrev = worldPos - previousCameraPosition;

    vec4 prevView = gbufferPreviousModelView * vec4(worldPosPrev, 1.0);
    vec4 prevClip = gbufferPreviousProjection * prevView;
    vec2 prevUV = (prevClip.xy / prevClip.w) * 0.5 + 0.5;

    vec2 velocity = (uv - prevUV) * 0.5; // 0.5 = força do blur, evita exagero em giros rápidos de câmera

    vec3 sum = texture2D(colortex0, uv).rgb;
    const int SAMPLES = 5;
    for (int i = 1; i < SAMPLES; i++) {
        sum += texture2D(colortex0, uv - velocity * (float(i) / float(SAMPLES))).rgb;
    }
    return sum / float(SAMPLES);
}
#endif

void main() {
    vec3 color;

    #if MOTION_BLUR_ENABLED == 1
    color = auris_motionBlur(texcoord);
    #elif DOF_ENABLED == 1
    color = auris_depthOfField(texcoord, centerDepthSmooth);
    #else
    color = texture2D(colortex0, texcoord).rgb;
    #endif

    #if EYE_ADAPTATION == 1
    // Aproximação barata de auto-exposure: usa centerDepthSmooth só como
    // proxy indireto não seria correto pra luminância, então aqui fazemos
    // 1 sample extra no centro da tela com um pequeno blur em vez de um
    // passe de downsample dedicado — suficiente pra reagir a mudanças
    // bruscas (entrar numa caverna) sem o custo de um mip completo de
    // luminância.
    float centerLum = luminance(texture2D(colortex0, vec2(0.5)).rgb);
    float exposure = clamp(0.6 / max(centerLum, 0.05), 0.6, 2.2);
    color *= exposure;
    #endif

    color = auris_tonemapACES(color);
    color = auris_colorGrade(color);

    gl_FragColor = vec4(color, 1.0);
}
