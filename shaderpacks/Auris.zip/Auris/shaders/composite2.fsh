/*
 * ============================================================================
 *  AURIS SHADER — composite2.fsh
 * ============================================================================
 *  Dois trabalhos neste passe, ambos escritos por cima da mesma imagem:
 *
 *  1) BLOOM (BLOOM_QUALITY) — extrai o brilho acima de um threshold e
 *     borra com poucos taps. Nível 1 (barato) faz 1 blur de 9 taps direto
 *     na resolução da tela; nível 2 (completo) faz um blur maior com raio
 *     efetivo mais largo simulando uma mip chain sem precisar de passes
 *     de composite extras — troca "menos passes" por "kernel um pouco
 *     mais caro", que ainda sai mais barato que 3-4 downsample passes
 *     completos no orçamento do High/Ultra.
 *
 *  2) REPROJEÇÃO TEMPORAL — em vez de rodar SSAO/VL/nuvens com mais
 *     samples por frame pra reduzir ruído (força bruta), o Auris acumula
 *     1 sample novo por frame e mistura com o histórico do frame
 *     anterior (colortex4), reprojetado via as matrizes de câmera do
 *     frame passado. Isso é o que permite VL_STEPS=8 (Medium) ou
 *     SSAO_SAMPLES=4 parecerem estáveis em vez de ruidosos.
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"

/* DRAWBUFFERS:04 */

varying vec2 texcoord;

uniform sampler2D colortex0; // cena com fog + VL + nuvens já aplicados
uniform sampler2D colortex4; // histórico (frame anterior) para reprojeção
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform vec3 previousCameraPosition;
uniform vec3 cameraPosition;
uniform float viewWidth;
uniform float viewHeight;

vec3 auris_sampleBloom(vec2 uv, float threshold, int radius) {
    vec2 texel = 1.0 / vec2(viewWidth, viewHeight);
    vec3 sum = vec3(0.0);
    float weightSum = 0.0;

    for (int x = -radius; x <= radius; x++) {
        for (int y = -radius; y <= radius; y++) {
            vec3 s = texture2D(colortex0, uv + vec2(x, y) * texel * 2.0).rgb;
            float lum = luminance(s);
            float bright = max(lum - threshold, 0.0);
            float w = 1.0 / (1.0 + float(x * x + y * y));
            sum += s * bright * w;
            weightSum += w;
        }
    }
    return sum / max(weightSum, 0.0001);
}

void main() {
    vec4 sceneColor = texture2D(colortex0, texcoord);
    vec3 result = sceneColor.rgb;

    // ---- Bloom ----
    #if BLOOM_QUALITY == 1
    result += auris_sampleBloom(texcoord, 0.9, 1) * 0.35; // kernel 3x3, threshold alto
    #elif BLOOM_QUALITY == 2
    result += auris_sampleBloom(texcoord, 0.7, 3) * 0.45; // kernel 7x7, threshold mais baixo (pega mais brilho)
    #endif

    // ---- Reprojeção temporal ----
    float depth = texture2D(depthtex0, texcoord).r;
    if (depth < 0.9999) {
        vec3 viewPos = viewSpaceFromDepth(texcoord, depth, gbufferProjectionInverse);
        vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
        vec3 worldPosPrev = worldPos - previousCameraPosition;

        vec4 prevView = gbufferPreviousModelView * vec4(worldPosPrev, 1.0);
        vec4 prevClip = gbufferPreviousProjection * prevView;
        vec2 prevUV = (prevClip.xy / prevClip.w) * 0.5 + 0.5;

        if (prevUV.x >= 0.0 && prevUV.x <= 1.0 && prevUV.y >= 0.0 && prevUV.y <= 1.0) {
            vec3 history = texture2D(colortex4, prevUV).rgb;
            result = mix(result, history, TAA_BLEND_WEIGHT);
        }
    }

    gl_FragData[0] = vec4(result, sceneColor.a); // colortex0: resultado deste frame (pra final.fsh)
    gl_FragData[1] = vec4(result, sceneColor.a); // colortex4: vira o histórico do próximo frame
}
