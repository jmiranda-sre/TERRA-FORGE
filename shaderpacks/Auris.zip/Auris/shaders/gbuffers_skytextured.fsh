#version 120

#include "/lib/settings.glsl"

/* DRAWBUFFERS:0 */

varying vec2 texcoord;
varying vec4 vertexColor;

uniform sampler2D texture;
uniform float rainStrength;

void main() {
    vec4 tex = texture2D(texture, texcoord) * vertexColor;
    // Some sol/lua/estrelas gradualmente com a chuva, em vez de sumirem
    // de forma abrupta (mais barato que uma segunda textura de "céu nublado").
    tex.a *= (1.0 - rainStrength * 0.85);
    if (tex.a < 0.02) discard;
    gl_FragData[0] = tex;
}
