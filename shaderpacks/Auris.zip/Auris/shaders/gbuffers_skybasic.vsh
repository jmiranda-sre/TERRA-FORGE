/*
 * ============================================================================
 *  AURIS SHADER — gbuffers_skybasic.vsh  (variante OVERWORLD — arquivo base)
 * ============================================================================
 *  Desenha o céu procedural, a linha do horizonte de void e a névoa de
 *  fundo. Nether usa world-1/gbuffers_skybasic.vsh|fsh (sem sol/lua,
 *  ambiente vermelho-alaranjado); End usa world1/gbuffers_skybasic.vsh|fsh
 *  (ambiente violeta escuro, sem sol/lua). Ver nota em lib/fog.glsl sobre
 *  o mecanismo de override por pasta de dimensão do Iris/OptiFine.
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"

varying vec3 viewDir;

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;

void main() {
    gl_Position = ftransform();

    vec4 clip = gl_Position;
    vec4 view = gbufferProjectionInverse * clip;
    viewDir = normalize((gbufferModelViewInverse * vec4(view.xyz / view.w, 0.0)).xyz);
}
