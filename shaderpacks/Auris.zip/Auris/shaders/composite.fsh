/*
 * ============================================================================
 *  AURIS SHADER — composite.fsh  (variante OVERWORLD — arquivo base)
 * ============================================================================
 *  Aplica a névoa (lib/fog.glsl) sobre a cena já com AO/GI resolvidos
 *  por deferred.fsh. Nether e End têm suas próprias cópias deste arquivo
 *  em world-1/composite.fsh e world1/composite.fsh, cada uma com
 *  parâmetros de névoa/ambiente próprios — ver a nota completa sobre o
 *  mecanismo de override por pasta em lib/fog.glsl.
 *
 *  Ativo em: todos os profiles, custo O(1) (não depende de nenhum
 *  #define de profile — a névoa em si nunca é a parte cara do pipeline).
 * ============================================================================
 */
#version 120

#include "/lib/settings.glsl"
#include "/lib/utils.glsl"
#include "/lib/fog.glsl"
#include "/lib/sky.glsl"

/* DRAWBUFFERS:0 */

varying vec2 texcoord;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform vec3 sunPosition;
uniform float rainStrength;
uniform float worldTime;
uniform float near;
uniform float far;
uniform int isEyeInWater;

void main() {
    vec4 sceneColor = texture2D(colortex0, texcoord);
    float depth = texture2D(depthtex0, texcoord).r;

    if (depth >= 0.9999) {
        // Céu: já é o gradiente correto, não precisa de névoa em cima.
        gl_FragData[0] = sceneColor;
        return;
    }

    vec3 viewPos = viewSpaceFromDepth(texcoord, depth, gbufferProjectionInverse);
    float viewDistance = length(viewPos);
    vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;

    float timeOfDay = auris_timeOfDayFactor(fract(worldTime / 24000.0));

    vec3 result;
    if (isEyeInWater == 1) {
        result = auris_applyWaterFog(sceneColor.rgb, vec3(0.35, 0.09, 0.06), viewDistance);
    } else {
        result = auris_applyOverworldFog(sceneColor.rgb, fogColor, viewDistance, worldPos.y, rainStrength, timeOfDay);
    }

    gl_FragData[0] = vec4(result, sceneColor.a);
}
