# Auris Shader — Resumo Técnico

Shaderpack original para Iris (formato Iris/OptiFine-extended), construído do
zero com o objetivo central de **melhor custo-benefício do mercado**: fidelidade
visual próxima ao Solas Shader, custo de frame-time próximo ao MakeUp - Ultra
Fast Shaders / BSL em seus perfis mais leves.

Testado contra `iris-fabric-1.10.9+mc26.1.1.jar` (Iris 1.10.9), compatível com
Minecraft 26.1.1 e 26.1.2 sem alteração nenhuma no `shaders.properties` — o
Iris 1.10.9 declara suporte à faixa 26.1–26.1.2, então nenhuma feature usada
aqui depende de comportamento específico de uma sub-versão.

---

## 1. Técnicas usadas por profile, e por quê

### Princípio geral
Cada feature é controlada por um `#define` em `lib/settings.glsl` testado via
`#if`/`#ifdef` real nos arquivos `.fsh`/`.vsh` — quando uma feature está
desligada, o branch inteiro (incluindo as declarações de uniform que só
aquele branch usa) some do shader compilado. Os 4 `profile.*` do
`shaders.properties` não são a lógica em si: são atalhos que sobrescrevem os
valores dessas macros em lote. Isso significa que qualquer combinação manual
de opções (fora dos 4 profiles prontos) também corta código morto do mesmo
jeito — os profiles são conveniência de UX, não uma camada de lógica separada.

| Feature | Low | Medium | High | Ultra |
|---|---|---|---|---|
| Shadow map | 1024, 1 sample | 2048, PCF 4 samples + distorção | 3072, PCSS + distorção + sombra colorida | 4096, PCSS (mais blocker samples) + colorida |
| SSAO | off | 4 samples | 8 samples | 16 samples |
| GI aproximado | off | off | bounce screen-space (1 sample, reaproveita blur do bloom) | idem |
| Água | especular puro (1 `pow`) | + reflexo de céu, refração leve | SSR (32 steps) + refração "Snell", parallax opcional | SSR (64 steps) + caustics |
| Volumétricos | off | god rays 8-12 steps | god rays 16-24 steps + nuvens raymarch 3D (10 steps) | god rays 32 steps + nuvens 3D (24 steps) |
| Bloom | off | 1 downsample (3x3) | kernel 7x7 | kernel 7x7 |
| DOF / Motion blur / POM / auto-exposure | off | off | off (toggle manual) | ligados |

Por que essas escolhas:

- **Sombras**: em vez de cascatas reais (2-4 shadow maps, 2-4 draw calls do
  mundo por frame), o Auris usa **um único shadow map com projeção
  distorcida** (`SHADOW_DISTORT`, em `lib/shadows.glsl`) — um warp não-linear
  que comprime a periferia e expande o centro, concentrando resolução perto
  do jogador. Isso aproxima o *efeito* de uma cascata próxima sem o custo de
  renderizar geometria do mundo múltiplas vezes por frame, que é exatamente
  onde CSM real fica caro.
- **PCSS só em High/Ultra**: busca de blocker (para penumbra variável) custa
  amostras extras de depth; em Low/Medium isso não compensa porque a
  resolução do shadow map já é baixa o bastante pra esconder a diferença.
- **SSAO com espiral áurea** (golden angle) em vez de kernel pré-gerado
  estático: decorrelaciona amostras sem precisar carregar/declarar um array
  de vetores de kernel, e com dithering temporal (1 sample novo por frame +
  reprojeção em `composite2.fsh`) o resultado fica estável com poucos
  samples.
- **Água sem geometria tesselada em nenhum profile** — toda a "onda" vem de
  normal mapping procedural (soma de senoides com derivada parcial
  aproximada). SSR só em High/Ultra, com early-exit assim que o raio sai da
  tela ou encontra um hit, e passo crescente (`stepSize *= 1.08`) pra cobrir
  mais distância com menos steps.
- **Nuvens**: Low fica sem nuvens (a missão pede zero raymarch caro no perfil
  baixo). Medium usa um plano 2D com FBM — 1 interseção de raio + ruído, sem
  loop de marcha. High/Ultra usam raymarch 3D real, mas com step count fixo e
  early-exit assim que o alpha acumulado satura (~0.98), então a marcha para
  antes do fim do range na maioria dos frames com céu nublado.
- **GI aproximado**: em vez de voxel-cone-tracing (caro demais pro
  orçamento do Auris em qualquer profile), a "luz indireta" é aproximada
  reamostrando, na direção da normal, uma versão já borrada do frame anterior
  — reaproveitando o mesmo buffer de bloom, então o custo marginal é ínfimo.
  Não é GI fisicamente correto; é uma aproximação perceptual barata,
  consciente da troca que está fazendo.
- **Reprojeção temporal em vez de força bruta**: SSAO, volumetric light,
  nuvens 3D e SSR usam jitter temporal + acumulação com o histórico do frame
  anterior (`colortex4`, `colortex4.clear=false` no `shaders.properties`) em
  vez de multiplicar samples por frame. É o que permite, por exemplo,
  `VL_STEPS=8` no Medium parecer estável em vez de ruidoso.

---

## 2. Compatibilidade Overworld / Nether / End

O Auris **não usa nenhum `#ifdef NETHER`/`#ifdef END`** — essas macros não
existem como padrão no formato Iris/OptiFine. Em vez disso, usa o mecanismo
real de override por pasta de dimensão que o Iris herda do OptiFine:

```
Auris/shaders/
├── shaders.properties
├── lib/            (Overworld — usado quando nenhuma pasta de dimensão sobrescreve)
├── gbuffers_*.vsh/fsh, composite*.vsh/fsh, ...   (Overworld)
├── world-1/        (NETHER — sobrescreve os arquivos de mesmo nome)
│   ├── lib/fog.glsl
│   ├── gbuffers_skybasic.vsh/fsh
│   └── composite.fsh, composite1.fsh
└── world1/         (END — sobrescreve os arquivos de mesmo nome)
    ├── lib/fog.glsl
    ├── gbuffers_skybasic.vsh/fsh
    └── composite.fsh, composite1.fsh
```

O Iris resolve `#include "/lib/fog.glsl"` e os programas de shader (`composite.fsh`,
`gbuffers_skybasic.fsh` etc.) para a versão da pasta da dimensão atual quando
ela existe, caindo de volta pra pasta raiz (Overworld) quando não existe.
Concretamente:

- **Nether** (`world-1/`): céu vira um teto quente/avermelhado sem gradiente
  de sol (não há `sunDir` relevante lá); fog exponencial bem mais denso e
  tingido de vermelho-alaranjado; `composite1.fsh` vira **passthrough puro**
  — sem god rays (não há sol visível) nem nuvens (não existem no Nether),
  economia de frame-time que o Overworld não tem, em nenhum profile.
- **End** (`world1/`): céu é um vazio quase preto com leve tom violeta; fog
  mais leve e sem variação por altura (não há "chão de referência" num vazio
  infinito); `composite.fsh` do End aplica um **piso mínimo de luz ambiente**
  sobre a cena (já que o `skyColor` do jogo vem quase preto sem sol/lua, e sem
  esse piso o terreno ficaria escuro demais fora do alcance de end rods);
  `composite1.fsh` também é passthrough (sem sol, sem nuvens).
- Os arquivos de `gbuffers_terrain/water/entities/hand` **não têm nenhum
  código específico de dimensão** — o modelo de luz deles já lê `sunPosition`,
  `skyColor` e o lightmap vanilla normalmente, que o próprio jogo já ajusta
  por dimensão. A dimensão só precisa de tratamento especial onde o Auris
  calcula algo que o vanilla não fornece pronto (céu procedural, fog, piso de
  ambiente) — daí os overrides ficarem concentrados exatamente nesses 3
  arquivos por dimensão, e não espalhados por todo o pack.

---

## 3. Limitações conhecidas do Iris 1.10.9 consideradas no design

O Iris é uma camada de compatibilidade com o formato de shaderpack do
OptiFine, não uma reimplementação byte-a-byte — por isso o Auris evitou
depender de comportamentos de borda que variam entre versões/forks:

- **Sem compute shaders**: mesmo onde compute shaders dariam ganho real (ex:
  um passe de blur separável de verdade para o bloom, ou geração de nuvens em
  uma textura 3D pré-computada), o Auris usa apenas fragment shaders
  full-screen. Suporte a compute shaders no ecossistema Iris/OptiFine tem
  variado entre versões e não é algo em que valha a pena apostar
  compatibilidade num pack cujo objetivo central é rodar bem até em GPU
  integrada.
- **Sem features de PBR "resource pack" (specular/normal maps por textura,
  convenção `_s`/`_n`)**: o Auris não assume que o resource pack do jogador
  vai ter texturas PBR nesse formato. Toda a "normal" usada em água e
  parallax é procedural, calculada em shader — isso também é o que mantém o
  pack funcional em qualquer resource pack vanilla-like, sem depender de
  assets extras.
- **PCSS e SSR usam raio de busca fixo, não uma blocker-search geometricamente
  exata**: blocker search "de livro-texto" para PCSS precisa de um segundo
  bind de depth texture dedicado e mais amostras pra ser preciso a qualquer
  distância; o Auris usa um raio de busca fixo pequeno (documentado em
  `lib/shadows.glsl`) que dá a impressão de penumbra variável sem esse custo
  extra — uma escolha deliberada de aproximação visual em vez de
  correção física, coerente com o objetivo de custo-benefício do pack.
- **`shadowcolor0`/sombra colorida depende do shadow pass escrever alpha
  parcial em blocos translúcidos** (`shadow.fsh`): isso funciona de forma
  consistente no Iris 1.10.9, mas qualquer resource pack ou mod que altere
  como blocos translúcidos são classificados no render pode precisar de
  ajuste fino no corte de alpha (`if (tex.a < 0.1) discard;`).
- **Dependência do mecanismo de override por pasta de dimensão** (`world-1`,
  `world1`) para o tratamento de Nether/End: esse mecanismo é herdado do
  OptiFine e é bem estabelecido no Iris, mas não existe validação
  automática de que os arquivos de override têm as mesmas variáveis
  varying/uniforms esperadas pelo `.vsh` correspondente — qualquer edição
  futura em um arquivo do Overworld (ex: adicionar uma varying nova em
  `gbuffers_skybasic.vsh`) precisa ser replicada manualmente nos `.vsh` de
  `world-1`/`world1`, já que eles não herdam do arquivo raiz automaticamente.

---

## 4. Honestidade sobre o estado deste pacote

Este é um shaderpack **funcional e arquiteturalmente completo** — todos os
programas exigidos pela especificação existem, com a separação de profiles
implementada via corte real de código morto, e o tratamento de dimensão
implementado via o mecanismo correto do Iris (não gambiarra de `#ifdef`).
Ainda assim, nenhuma linha aqui foi testada dentro do jogo: valores de bias,
densidade de fog, força de bloom, threshold de PCSS etc. são pontos de
partida razoáveis (baseados em como shaders desse gênero costumam calibrar
essas constantes), não números validados visualmente em Minecraft rodando.
Espere precisar ajustar constantes depois da primeira sessão de teste in-game
— isso é normal para qualquer shaderpack novo, não um sinal de que a
arquitetura está errada.

Nenhum trecho de código ou asset foi copiado de shaders existentes (Solas,
BSL, MakeUp, Complementary etc.) — a referência usada foi apenas de estilo
visual e filosofia de performance, conforme pedido.

`pack.png` não foi gerado como imagem (conforme permitido na especificação):
para uma miniatura simples, um ícone com um "olho"/íris estilizado em tons
de azul-violeta sobre fundo escuro comunicaria bem o nome "Auris" (do latim
*auris*, "ouvido", mas aqui usado como jogo de palavras com "Iris").
