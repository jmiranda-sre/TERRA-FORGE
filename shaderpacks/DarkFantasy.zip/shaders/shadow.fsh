#version 120

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;

void main() {
    vec4 albedo = texture2D(texture, texcoord) * glcolor;

    if (albedo.a < 0.1) discard;

    float lum = dot(albedo.rgb, vec3(0.299, 0.587, 0.114));
    vec3 shadowColor = vec3(lum) * vec3(0.82, 0.88, 1.0);

    gl_FragColor = vec4(shadowColor, 1.0);
}
