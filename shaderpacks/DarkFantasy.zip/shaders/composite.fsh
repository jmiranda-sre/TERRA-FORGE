#version 120

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;
uniform float worldTime;
uniform vec3 sunPosition;
uniform mat4 gbufferProjectionInverse;
uniform vec2 texelSize;

varying vec2 texcoord;

vec3 getViewPos(vec2 coord, float depth) {
    vec4 pos = vec4(coord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    pos = gbufferProjectionInverse * pos;
    return pos.xyz / pos.w;
}

float vignette(vec2 uv) {
    uv = uv * 2.0 - 1.0;
    return smoothstep(1.35, 0.35, dot(uv, uv));
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    vec2 lmcoord = texture2D(colortex1, texcoord).rg;
    float depth = texture2D(depthtex0, texcoord).r;

    float nightFactor = smoothstep(12000.0, 15000.0, worldTime);

    if (depth < 1.0) {
        vec3 viewPos = getViewPos(texcoord, depth);
        float dist = length(viewPos);

        float fog = smoothstep(22.0, 120.0, dist);
        vec3 fogColor = mix(vec3(0.05, 0.055, 0.065), vec3(0.015, 0.02, 0.03), nightFactor);
        color = mix(color, fogColor, fog * 0.9);

        color *= mix(1.0, 0.82, fog);
    }

    float torchIntensity = pow(lmcoord.x, 4.0);
    vec3 torchLight = vec3(1.0, 0.42, 0.12);
    color += torchLight * torchIntensity * 1.15;

    vec3 viewPos = getViewPos(texcoord, depth);
    vec3 viewDir = normalize(-viewPos);
    vec3 sunDir = normalize(sunPosition);

    float moonScatter = pow(max(dot(sunDir, viewDir), 0.0), 6.0);
    color += vec3(0.18, 0.22, 0.35) * moonScatter * nightFactor * 0.45;

    float godray = pow(max(dot(sunDir, viewDir), 0.0), 9.0);
    float isDay = 1.0 - smoothstep(12000.0, 13250.0, worldTime);
    color += vec3(0.55, 0.48, 0.4) * godray * 0.1 * isDay;

    color *= mix(1.0, 0.28, nightFactor);
    color.rgb *= mix(vec3(1.0), vec3(0.72, 0.78, 0.95), nightFactor);

    float brightness = max(color.r, max(color.g, color.b));
    if (brightness > 0.65) {
        color += color * 0.12;
    }

    if (depth < 1.0) {
        float d0 = texture2D(depthtex0, texcoord + vec2(texelSize.x, 0.0)).r;
        float d1 = texture2D(depthtex0, texcoord + vec2(-texelSize.x, 0.0)).r;
        float d2 = texture2D(depthtex0, texcoord + vec2(0.0, texelSize.y)).r;
        float d3 = texture2D(depthtex0, texcoord + vec2(0.0, -texelSize.y)).r;

        float diff = abs(depth - d0) + abs(depth - d1) + abs(depth - d2) + abs(depth - d3);
        float ao = 1.0 - clamp(diff * 55.0, 0.0, 1.0) * 0.72;
        color *= pow(ao, 1.8);
    }

    color *= vignette(texcoord);

    float grain = fract(sin(dot(texcoord.xy, vec2(91.222, 17.731))) * 43758.5453);
    color += (grain - 0.5) * 0.015;

    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
