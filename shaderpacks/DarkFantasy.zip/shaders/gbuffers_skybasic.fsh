#version 120

uniform float worldTime;
uniform vec3 fogColor;

varying vec2 texcoord;

void main() {
    vec3 sky = vec3(0.08, 0.09, 0.12);

    float sunsetFactor = 0.0;
    float t = worldTime;

    if (t > 11000.0 && t < 13000.0) {
        sunsetFactor = 1.0 - abs(t - 12000.0) / 1000.0;
    } else if (t > 23000.0 || t < 1000.0) {
        float dawn = t > 23000.0 ? t - 24000.0 : t;
        sunsetFactor = 1.0 - abs(dawn) / 1000.0;
    }

    sky += vec3(0.25, 0.12, 0.05) * sunsetFactor;

    gl_FragColor = vec4(sky, 1.0);
}
