#version 120


uniform sampler2D texture;
uniform sampler2D lightmap;
uniform vec4 entityColor;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;

void main() {
    vec4 albedo = texture2D(texture, texcoord) * glcolor;

    vec3 light = texture2D(lightmap, lmcoord).rgb;
    light = max(light, vec3(0.06));

    vec3 color = albedo.rgb * light;

    gl_FragData[0] = vec4(color, albedo.a);

    gl_FragData[1] = vec4(lmcoord, 0.0, 1.0);
}
