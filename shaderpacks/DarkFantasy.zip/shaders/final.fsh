#version 120

uniform sampler2D colortex0;
uniform float worldTime;

varying vec2 texcoord;

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    float luminance = dot(color, vec3(0.299, 0.587, 0.114));

    color = mix(vec3(luminance), color, 0.52);

    color.r *= 0.92;
    color.g *= 0.9;
    color.b *= 1.08;

    color = pow(color, vec3(1.35));

    float highlights = smoothstep(0.55, 1.0, luminance);
    color += vec3(0.08, 0.01, 0.01) * highlights;

    float dusk = smoothstep(10000.0, 14000.0, worldTime);
    color *= mix(vec3(0.9, 0.92, 0.95), vec3(0.72, 0.76, 0.88), dusk);

    color *= 0.78;

    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
