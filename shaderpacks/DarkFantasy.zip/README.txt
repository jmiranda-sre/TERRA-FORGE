Dark Fantasy Shader Pack
========================

A cinematic, gloomy Minecraft shaderpack inspired by:
  - Dark Souls / Demon's Souls
  - Elden Ring
  - Skyrim
  - Blasphemous

Visual Targets
-------------
- Shadows      : Cold blue-gray
- Fire/Torches : Warm orange
- Fog          : Thick and distant
- Sky          : Stormy / desaturated
- Bloom        : Soft, not neon
- Saturation   : Reduced
- Contrast     : High
- Ambient Light: Low

Files
-----
- final.fsh          : Color grading (desaturation, cold shadows, filmic contrast)
- composite.fsh      : Fog, torchlight, god rays, night tint, bloom, AO, film grain
- gbuffers_terrain.fsh: Terrain shading with crushed ambient light
- gbuffers_skybasic.fsh: Dark stormy sky with sunset tint
- shadow.fsh         : Cold blue-tinted shadow map
- shader.properties    : Pack metadata

Installation
------------
1. Copy the "DarkFantasy" folder into your .minecraft/shaderpacks/ directory.
2. Select it in Options > Video Settings > Shaders.
3. Requires OptiFine or Iris.

Tweaking
--------
Edit the .fsh files to adjust:
- fog start/end distances (composite.fsh, smoothstep)
- torch warmth (composite.fsh, torchLight vec3)
- desaturation amount (final.fsh, mix factor 0.65)
- overall darkness (final.fsh, color *= 0.82)
- god ray intensity (composite.fsh, * 0.15)
- night darkness (composite.fsh, color *= 0.35)
