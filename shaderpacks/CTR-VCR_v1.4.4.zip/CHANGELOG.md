## 1.4.4
### Fixes
- Fixed compilation issue for older GLSL compilers. [#6](https://github.com/millennIumAMbiguity/ctrvcr/pull/6)

## 1.4.3
### Additions
- Added dynamic fog.
### Changes
- AIWS no longer affects hand, snow, and rain.
- Tweaked AIWS.
- Tweaked lighting.
- Updated profiles.
### Fixes
- Fixed small issues with fog.

## 1.4.2
### Fixes
- Fixed bug for distant horizons

## 1.4.1
### Changes
- Updated fog.
### Fixes
- Fixed mobs not affected by fog in some cases.
- Fixed sky being black under water.

## 1.4.0
### Additions
- Added night sky light color configs.
- Added config to reduce colors.
- Added 2 ditherings for reduced color modes.
- Added saturation config.
- Added config for reducing floating point precision.
- Added `Macintosh color classic` preset.
### Changes
- Renamed `Sky` RGB colors to `Day`.
- Renamed `Tint` to `Color`.
- Updated presets.
### Fixes
- Fixed shader crash when disabling dither fog in some cases.
- Minor fix/tweak to fog.

## 1.3.1
### Additions
- Added `Dynamic Lighting`.
- Added Dynamic Light RGB configs.
### Fixes
- Added missing texts.
- Fixed speling issue with som vars.

## 1.3.0
### Additions
- Added Distant Horizons support.
- Added config `Discard Sky`.
- Added config `Fog Mult`.
### Changes
- Changed rendering for non-terrain things like block outline, sky, and fog.
### Fixes
- Fixed typo in config value.

## 1.2.3
### Fixes
- Fixed bug related to frameTimeCounter.

## 1.2.2
### Additions
- Added config `Vanilla Light`-
### Changes
- `Ditter Fog` is now disabled by default.
- `Portal Static`, `Portal Static Particles`, and `Vanilla Light` are now disabled when using Optifine.
### Fixes
- Fixed bug when `Moonlight Strength` was disabled.
- Fixes several issues that occurred when using Optifine.

## 1.2.1
### Fixes
- Fixed error for AMD GPUs.

## 1.2.0
### Additions
- Added profiles.
- Added sunrise tint config.
- Added option to perform BNW before tint.
- Added config for moonlight brightness.
### Changes
- Changed SCREEN_TEAR_SOLID default to false.
- Changed AIWS default to Disabled.
- Several changes to configs.
### Fixes
- Fixed issues with lightning.
- Fixed bug where DARKNESS_INTENSITY did not work when under 1.0x.

## 1.1.9
### Additions
- Added LIGHTMAP_DITERING.
- Added LIGHTNING_STRENGTH.
- Added DARKNESS_INTENSITY.
- Added DITTER_FOG.
- Added AIWS mode Fluids.
### Changes
- Changed default AIWS_INTENSITY from 1.0 to 0.5
- Changed default BLOOM_SIZE from 0.8 to 0.9
- Set AIWS default to Fluids.

## 1.1.8
### Fixes
- Fixed purple edge on portals.
- Fixed incorrect shader format version.

## 1.1.7
### Additions
- Added AIWS texture distortion. (Disabled by default.)
### Fixes
- Fixed bug when BLUR_SIZE and BLOOM_SIZE were off.

## 1.1.6
### Changes
- Fixed slow noise.
- Fixed off state for static tear.
### Additions
- Added grain.

## 1.1.5
### Changes
- Improved noise functions.

## 1.1.4
### Additions
- Added RGB color tint.
- Added black and white filter.
- Added language file.

## 1.1.3
### Changes
- Screen tear can now be either transparent or solid.
### Fixes
- General fixes.

## 1.1.2
### Fixes
- General fixes.

## 1.1.1
### Additions
- Added options to change the target pixel size of rendering, effects, and scan line.
### Changes
- Moved configs into categories.

## 1.1.0
### Additions
- Added scan-lines.
- Added Slider for scan-lines.
### Changes
- Changed config "DARK_EDGES" from a toggle to a slider.
- Changed glsl version to 130.
### Fixes
- Fixed bug that causes static tear not to work as intended.
- Fixed bugs regarding screen tear when speed was set to 0.

## 1.0.2
### Fixes
- Fixed an issue that accrued with some shader mods.

## 1.0.1
### Additions
- Added config to control the greenness.
### Changes
- Optimized shader.
- Improved distortions

## 1.0.0
### Additions
- Added portal static
- Added configs

## 0.1.0
- Initial commit
