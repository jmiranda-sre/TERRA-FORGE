#ifndef INCLUDE_ENDER_BLACKHOLE
    #define INCLUDE_ENDER_BLACKHOLE

    // Author: devendrn, Title: Simple blackhole, License: CC BY-SA 4.0

    #ifdef END_BLACKHOLE

    vec3 GetBlackholeColLow() {
        return vec3(0.1, 0.2, 0.1) * vec3(END_BLACKHOLE_R, END_BLACKHOLE_G, END_BLACKHOLE_B) * 0.01;
    }

    vec3 GetBlackholeColHigh() {
        return vec3(0.75, 0.65, 0.9) * vec3(END_BLACKHOLE_R, END_BLACKHOLE_G, END_BLACKHOLE_B) * 0.01;
    }

    float GetBlackholeDist() {
        return 2.4 * END_BLACKHOLE_SIZE * 0.01;
    }

    float GetBlackholeSpeed() {
        return 0.6 * END_BLACKHOLE_SPEED * 0.01;
    }

    float GetBlackholeBloomMult() {
        return max(END_BLACKHOLE_BLOOM * 0.01, 0.2);
    }

    vec4 renderBlackhole(vec3 vdir, float t) {
        float bhSpeed = GetBlackholeSpeed();
        float bhDist = GetBlackholeDist();
        float bloomMult = GetBlackholeBloomMult();
        float intensity = END_BLACKHOLE_I * 0.01;
        vec3 colLow = GetBlackholeColLow();
        vec3 colHigh = GetBlackholeColHigh();

        t *= bhSpeed;

        float r = 2.4;
        vec3 vr = vdir;
        vr.xy = mat2(cos(r), -sin(r), sin(r), cos(r)) * vr.xy;

        vec3 vd = vr - vec3(0.0, -1.0, 0.0);
        float nl = sin(15.0 * vd.x + t) * sin(15.0 * vd.y - t) * sin(15.0 * vd.z + t);
        float a = atan(vd.x, vd.z);

        float d = bhDist * length(vd + 0.003 * nl);
        float d0 = (0.6 - d) / 0.6;
        float dm0 = 1.0 - max(d0, 0.0);

        float gl = 1.0 - clamp(-0.3 * d0, 0.0, 1.0);
        float gla = pow(1.0 - min(abs(d0), 1.0), 8.0 / bloomMult);
        float gl8 = pow(gl, 8.0 / bloomMult);

        float hole = 0.9 * pow(dm0, 32.0) + 0.1 * pow(dm0, 3.0);
        float bh = (gla + 0.8 * gl8 + 0.2 * gl8 * gl8) * hole;

        float df = sin(3.0 * a - 4.0 * d + 24.0 * pow(1.4 - d, 4.0) + t);
        df *= 0.9 + 0.1 * sin(8.0 * a + d + 4.0 * t - 4.0 * df);
        bh *= 1.0 + pow(df, 4.0) * hole * max(1.0 - bh, 0.0);

        vec3 col = bh * 2.0 * intensity * mix(colLow, colHigh, min(bh, 1.0));
        return vec4(col, hole);
    }

    void GetBlackholeField(vec3 vdir, float t, out float d, out float a) {
        t *= GetBlackholeSpeed();

        float r = 2.4;
        vec3 vr = vdir;
        vr.xy = mat2(cos(r), -sin(r), sin(r), cos(r)) * vr.xy;

        vec3 vd = vr - vec3(0.0, -1.0, 0.0);
        float nl = sin(15.0 * vd.x + t) * sin(15.0 * vd.y - t) * sin(15.0 * vd.z + t);
        a = atan(vd.x, vd.z);
        d = GetBlackholeDist() * length(vd + 0.003 * nl);
    }

    float GetBlackholeAbsorbStrength(vec3 vdir, float t) {
        float d, a;
        GetBlackholeField(vdir, t, d, a);

        float funnel = pow(clamp(1.55 - d, 0.0, 1.55) / 1.55, 2.2);
        float innerEdge = smoothstep(0.15, 0.38, d);
        float outerEdge = 1.0 - smoothstep(0.8, 1.45, d);
        float annulus = innerEdge * outerEdge;

        float streak = pow(0.5 + 0.5 * abs(sin(3.0 * a - 4.0 * d + 24.0 * pow(max(1.4 - d, 0.0), 4.0) + t)), 2.2);
        float absorb = funnel * mix(0.5, 1.0, annulus) * mix(0.78, 1.0, streak);

        return clamp(absorb, 0.0, 1.0);
    }

    vec3 ApplyBlackholeEnvironment(vec3 sky, vec3 vdir, float t) {
        float absorb = GetBlackholeAbsorbStrength(vdir, t);
        if (absorb < 0.001) return sky;

        vec4 bh = renderBlackhole(vdir, t);
        float d, a;
        GetBlackholeField(vdir, t, d, a);
        float streak = pow(0.5 + 0.5 * abs(sin(3.0 * a - 4.0 * d + 24.0 * pow(max(1.4 - d, 0.0), 4.0) + t * GetBlackholeSpeed())), 2.2);

        float strength = absorb * (1.0 - bh.a * 0.9);
        float outsideRing = 1.0 - bh.a;

        float darken = 1.0 - strength * (0.86 + 0.1 * streak);
        sky *= darken;

        vec3 infall = mix(GetBlackholeColLow(), GetBlackholeColHigh(), pow(strength, 0.55));
        infall *= strength * streak * 0.5;
        sky += infall * outsideRing;

        sky = mix(sky, sky * 0.28 + infall * 1.8, strength * 0.42 * outsideRing);

        return sky;
    }

    float GetBlackholeEnvBrightness(vec3 viewPos) {
        vec3 vdir = normalize((gbufferModelViewInverse * vec4(normalize(viewPos), 0.0)).xyz);
        float absorb = GetBlackholeAbsorbStrength(vdir, frameTimeCounter);
        if (absorb < 0.001) return 1.0;

        vec4 bh = renderBlackhole(vdir, frameTimeCounter);
        return 1.0 - absorb * (0.9 + 0.08 * absorb) * (1.0 - bh.a * 0.92);
    }

    vec3 ApplyEndBlackhole(vec3 sky, vec3 viewPos) {
        vec3 vdir = normalize((gbufferModelViewInverse * vec4(normalize(viewPos), 0.0)).xyz);
        float t = frameTimeCounter;

        sky = ApplyBlackholeEnvironment(sky, vdir, t);

        vec4 bh = renderBlackhole(vdir, t);
        sky *= bh.a;
        sky += bh.rgb;
        return sky;
    }

    #else

    float GetBlackholeEnvBrightness(vec3 viewPos) {
        return 1.0;
    }

    vec3 ApplyEndBlackhole(vec3 sky, vec3 viewPos) {
        return sky;
    }

    #endif //END_BLACKHOLE

#endif //INCLUDE_ENDER_BLACKHOLE
