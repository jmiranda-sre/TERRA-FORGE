#version 120

uniform sampler2D colortex0;
uniform float frameTimeCounter; // Used to animate the film grain noise

varying vec2 texcoord;

// Function to generate static noise / film grain
float rand(vec2 co){
    return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
}

void main() {
    // Get the original game screen color
    vec3 color = texture2D(colortex0, texcoord).rgb;

    // --- 1. CONTRAST & NIGHT LIGHTING (SPOOKY MOONLIGHT) ---
    // We lift the shadows so you can navigate, but keep the horror contrast
    color = pow(color, vec3(1.2)); // Softer shadow crush (was 1.6)
    color *= 0.85; // Bring back overall brightness (was 0.65)

    // Soft, pale blue-grey "ambient moonlight" so pitch-black areas are visible
    vec3 moonlightAmbient = vec3(0.015, 0.018, 0.025); 
    color += moonlightAmbient;

    // --- 2. SICKLY HORROR TINT & DESATURATION ---
    // Calculate brightness of the pixel
    float luminance = dot(color, vec3(0.299, 0.587, 0.114));
    
    // Find red colors (for blood, redstone, or red glowing eyes)
    float redIntensity = max(color.r - (color.g + color.b) / 2.0, 0.0);
    
    // Sickly, pale cold-greenish tint
    vec3 deadTint = vec3(0.75, 0.85, 0.8) * luminance; 
    
    // Mix natural colors and the dead tint (allowing slightly more color/torches to show)
    color = mix(deadTint, color, 0.35 + (redIntensity * 2.0));

    // --- 3. CLAUSTROPHOBIC VIGNETTE ---
    // Slightly wider vignette to open up more of the screen center
    vec2 center = texcoord - 0.5;
    float dist = length(center);
    float vignette = smoothstep(0.95, 0.45, dist); 
    color *= vignette;

    // --- 4. VHS / FILM GRAIN ---
    // Softened the film grain slightly so it doesn't block your vision in the dark
    float noise = rand(texcoord + frameTimeCounter) * 0.08;
    color -= noise; 

    // Clamp values to keep colors clean
    color = clamp(color, 0.0, 1.0);

    gl_FragColor = vec4(color, 1.0);
}