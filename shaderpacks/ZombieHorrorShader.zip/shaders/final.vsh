#version 120

varying vec2 texcoord;

void main() {
    // Pass the standard screen coordinates
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.st;
}