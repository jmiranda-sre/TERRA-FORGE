#version 120

uniform int entityId;
uniform sampler2D gtexture;

varying vec2 texcoord;
varying vec4 color;

void main() {
    vec4 texColor = texture2D(gtexture, texcoord);
    vec4 finalColor = texColor * color;

    float eps = 0.002;
    bool isEyeArea = false;

    // To make coordinates easier to read
    float u = texcoord.x;
    float v = texcoord.y;

    // --- 1. ZOMBIES & SKELETONS ---
    // Broad box around the eyes: U=10 to 14, V=11 to 14
    if (entityId == 10000) {
        if (u >= 10.0/64.0 - eps && u <= 14.0/64.0 + eps &&
            v >= 11.0/64.0 - eps && v <= 14.0/64.0 + eps) {
            isEyeArea = true;
        }
    }
    
    // --- 2. PIGS ---
    else if (entityId == 10001) {
        if (((u >= 10.0/64.0 - eps && u <= 11.0/64.0 + eps) || (u >= 13.0/64.0 - eps && u <= 14.0/64.0 + eps)) &&
            (v >= 11.0/64.0 - eps && v <= 13.0/64.0 + eps || v >= 11.0/32.0 - eps && v <= 13.0/32.0 + eps)) {
            isEyeArea = true;
        }
    }

    // --- 3. COWS ---
    else if (entityId == 10002) {
        if (((u >= 4.0/64.0 - eps && u <= 5.0/64.0 + eps) || (u >= 13.0/64.0 - eps && u <= 14.0/64.0 + eps)) &&
            (v >= 10.0/64.0 - eps && v <= 11.0/64.0 + eps || v >= 10.0/32.0 - eps && v <= 11.0/32.0 + eps)) {
            isEyeArea = true;
        }
    }

    // --- 4. SHEEP ---
    else if (entityId == 10003) {
        if (((u >= 7.0/64.0 - eps && u <= 8.0/64.0 + eps) || (u >= 10.0/64.0 - eps && u <= 11.0/64.0 + eps)) &&
            (v >= 8.0/64.0 - eps && v <= 9.0/64.0 + eps || v >= 8.0/32.0 - eps && v <= 9.0/32.0 + eps)) {
            isEyeArea = true;
        }
    }

    // --- 5. CHICKENS ---
    else if (entityId == 10004) {
        if (((u >= 1.0/64.0 - eps && u <= 2.0/64.0 + eps) || (u >= 8.0/64.0 - eps && u <= 9.0/64.0 + eps)) &&
            (v >= 5.0/64.0 - eps && v <= 6.0/64.0 + eps || v >= 5.0/32.0 - eps && v <= 6.0/32.0 + eps)) {
            isEyeArea = true;
        }
    }

    // --- 6. CREEPERS ---
    // Broad box around the eyes (avoiding the mouth)
    else if (entityId == 10005) {
        if (((u >= 9.0/64.0 - eps && u <= 12.0/64.0 + eps) || (u >= 14.0/64.0 - eps && u <= 17.0/64.0 + eps)) &&
            (v >= 9.0/64.0 - eps && v <= 12.5/64.0 + eps || v >= 9.0/32.0 - eps && v <= 12.5/32.0 + eps)) {
            isEyeArea = true;
        }
    }

    // --- THE MAGIC COLOR DETECTION ---
    // If the pixel is inside the eye area, AND the pixel is NOT transparent
    if (isEyeArea && texColor.a > 0.1) {
        
        // Calculate how dark the original pixel is
        float luminance = (texColor.r + texColor.g + texColor.b) / 3.0;
        
        // ONLY turn it red if the pixel is dark (black/dark green)!
        // This stops the green skin of a creeper/zombie from glowing.
        if (luminance < 0.3) {
            finalColor = vec4(1.0, 0.0, 0.0, 1.0); // Pure glowing red!
        }
    }

    gl_FragColor = finalColor;
}